"""
gen3lib.py - Core library for a Gen 3 (GBA) Pokemon romhack save editor.

Features
- Gen 3 text charset encode/decode
- Save parsing (two slots A/B, 14 sections, checksums, signature)
- Game family detection (RS / FRLG / Emerald) from the save itself
- Party + PC box Pokemon (encrypted 100/80 byte structures, substructure shuffling)
- Bag pockets (with security-key quantity encryption for FRLG/Emerald)
- ROM scanner: finds species / item / move name tables by structure, NOT by fixed
  offsets, so it also works for expanded romhacks.
"""
import struct

# ----------------------------------------------------------------------------
# Charset (Western, English)
# ----------------------------------------------------------------------------
_CHARS = {}
_CHARS[0x00] = " "
_up = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
_lo = "abcdefghijklmnopqrstuvwxyz"
for i, c in enumerate("0123456789"):
    _CHARS[0xA1 + i] = c
for i, c in enumerate(_up):
    _CHARS[0xBB + i] = c
for i, c in enumerate(_lo):
    _CHARS[0xD5 + i] = c
_CHARS.update({
    0xAB: "!", 0xAC: "?", 0xAD: ".", 0xAE: "-", 0xB0: "…", 0xB1: "“", 0xB2: "”",
    0xB3: "‘", 0xB4: "'", 0xB5: "♂", 0xB6: "♀", 0xB8: ",", 0xB9: "×", 0xBA: "/",
    0xF0: ":", 0x1B: "é", 0x5A: "Í", 0x79: "↑", 0x7A: "↓", 0x7B: "←", 0x7C: "→",
    0xA0: "…", 0xFE: "\n",
})
_ACCENTS = {0x01: "À", 0x02: "Á", 0x03: "Â", 0x04: "Ç", 0x05: "È", 0x06: "É", 0x07: "Ê", 0x08: "Ë",
            0x09: "Ì", 0x0B: "Î", 0x0C: "Ï", 0x0D: "Ò", 0x0E: "Ó", 0x0F: "Ô", 0x10: "Œ", 0x11: "Ù",
            0x12: "Ú", 0x13: "Û", 0x14: "Ñ", 0x15: "ß", 0x16: "à", 0x17: "á", 0x19: "ç", 0x1A: "è",
            0x1C: "ê", 0x1D: "ë", 0x1E: "ì", 0x20: "î", 0x21: "ï", 0x22: "ò", 0x23: "ó", 0x24: "ô",
            0x25: "œ", 0x26: "ù", 0x27: "ú", 0x28: "û", 0x29: "ñ", 0x2A: "º", 0x2B: "ª"}
for _k, _v in _ACCENTS.items():
    _CHARS.setdefault(_k, _v)
_REV = {v: k for k, v in _CHARS.items() if k not in (0xA0, 0xFE)}
_REV["\n"] = 0xFE
TERM = 0xFF


def decode_text(raw):
    out = []
    for b in raw:
        if b == TERM:
            break
        out.append(_CHARS.get(b, "?"))
    return "".join(out)


def encode_text(s, length, pad=True):
    data = bytearray()
    for ch in s[:length]:
        data.append(_REV.get(ch, _REV["?"]))
    if len(data) < length:
        data.append(TERM)
    if pad:
        while len(data) < length:
            data.append(TERM)
    return bytes(data[:length])


def lz77_decompress(d, o):
    """GBA BIOS LZ77 (type 0x10) at offset o of d; returns bytes or None."""
    try:
        if d[o] != 0x10:
            return None
        n = d[o + 1] | d[o + 2] << 8 | d[o + 3] << 16
        out = bytearray()
        p = o + 4
        while len(out) < n:
            flags = d[p]
            p += 1
            for b in range(8):
                if len(out) >= n:
                    break
                if flags & (0x80 >> b):
                    a, c = d[p], d[p + 1]
                    p += 2
                    disp = ((a & 15) << 8 | c) + 1
                    if disp > len(out):
                        return None
                    for _ in range((a >> 4) + 3):
                        out.append(out[-disp])
                else:
                    out.append(d[p])
                    p += 1
        return bytes(out[:n])
    except IndexError:
        return None


def is_gen3_text(raw):
    """True if bytes look like a valid terminated Gen3 string (letters mostly)."""
    n = 0
    for b in raw:
        if b == TERM:
            return n > 0
        if b not in _CHARS:
            return False
        n += 1
    return False


# ----------------------------------------------------------------------------
# Vanilla fallback names (used when no ROM is loaded)
# ----------------------------------------------------------------------------
def fallback_species(i):
    return f"Species #{i}"


def fallback_item(i):
    return "(none)" if i == 0 else f"Item #{i}"


def fallback_move(i):
    return "(none)" if i == 0 else f"Move #{i}"


# ----------------------------------------------------------------------------
# ROM scanner
# ----------------------------------------------------------------------------
# ROMs recognised by SHA-1 (taken from files supplied for testing). The generic scanner does not
# need this; it only adds a friendly name and lets the editor pick hack-specific behaviour.
KNOWN_ROMS = {
    "0f54a37fdae801a186068bdc0bbad8b77ec0d306": "Pokémon Unbound 2.0.3.2",
    "b4776b82a4c7915d0fadeaa27e013523f99dfd94": "Pokémon Unbound 2.1.1.1",
}


class RomInfo:
    CACHE_VERSION = 7
    _cache_file = None
    gfx = None                # sprite / palette table info (scanned lazily, see ensure_gfx)

    def __init__(self, data, cache_dir=None):
        """Scan `data` (ROM bytes) for name tables. If cache_dir is given, results are
        cached there per ROM hash, so re-opening a ROM is instant."""
        self.data = data
        self.game_title = data[0xA0:0xAC].rstrip(b"\x00").decode("ascii", "replace")
        self.game_code = data[0xAC:0xB0].decode("ascii", "replace")
        self.species_names = []   # index -> name
        self.item_names = []
        self.move_names = []
        self.item_table_offset = None
        self.species_table_offset = None
        self.move_table_offset = None
        self.move_pps = []        # base PP per move id (from the battle-move table), if found
        self.move_pp_offset = None
        self.base_stats_offset = None
        self.species_stats = []   # per species: [hp,atk,def,spe,spa,spd,gender,growth,ab1,ab2,hidden]
        self.ability_names = []
        self.ability_table_offset = None
        self.item_pockets = {}    # item id -> 'items' | 'keyitems' | 'balls' | 'tms' | 'berries'
        self.item_table_count = 0
        self.notes = []
        self.hack = self._detect_hack()
        cache_file = None
        if cache_dir:
            import hashlib, os
            os.makedirs(cache_dir, exist_ok=True)
            cache_file = os.path.join(cache_dir, hashlib.sha1(data).hexdigest() + ".json")
            self._cache_file = cache_file
            if self._load_cache(cache_file):
                return
        self._scan()
        if cache_file:
            self._save_cache(cache_file)

    def _detect_hack(self):
        """Name of the hack: exact SHA-1 match if known, otherwise by in-ROM text markers."""
        import hashlib
        h = hashlib.sha1(self.data).hexdigest()
        if h in KNOWN_ROMS:
            return KNOWN_ROMS[h]
        # Unbound: the intro text 'Welcome to Pokémon Unbound!' lives in the ROM (Gen3 encoded)
        if self.data.find(encode_text("to Pokémon Unbound!", 19, pad=False)) >= 0 or \
                self.data.find(encode_text("Pokémon Unbound", 15, pad=False)) >= 0:
            return "Pokémon Unbound (unknown version)"
        return ""

    def _load_cache(self, path):
        import json, os
        if not os.path.exists(path):
            return False
        try:
            c = json.load(open(path, encoding="utf-8"))
            if c.get("version") != self.CACHE_VERSION:
                return False
            for k in ("species_names", "item_names", "move_names", "item_table_offset",
                      "species_table_offset", "move_table_offset", "notes", "move_pps",
                      "move_pp_offset", "base_stats_offset", "species_stats", "ability_names",
                      "ability_table_offset", "item_pockets", "item_table_count"):
                setattr(self, k, c[k])
            self.item_pockets = {int(k): v for k, v in self.item_pockets.items()}
            self.gfx = c.get("gfx")
            self.notes = list(self.notes) + ["(loaded from cache)"]
            return True
        except Exception:
            return False

    def _save_cache(self, path):
        import json
        try:
            json.dump({"version": self.CACHE_VERSION, "species_names": self.species_names,
                       "item_names": self.item_names, "move_names": self.move_names,
                       "item_table_offset": self.item_table_offset,
                       "species_table_offset": self.species_table_offset,
                       "move_table_offset": self.move_table_offset, "notes": self.notes,
                       "move_pps": self.move_pps, "move_pp_offset": self.move_pp_offset,
                       "base_stats_offset": self.base_stats_offset,
                       "species_stats": self.species_stats, "ability_names": self.ability_names,
                       "ability_table_offset": self.ability_table_offset,
                       "item_pockets": self.item_pockets, "item_table_count": self.item_table_count,
                       "gfx": self.gfx},
                      open(path, "w", encoding="utf-8"), ensure_ascii=False)
        except Exception:
            pass

    # --- generic fixed-stride name table finder --------------------------------
    def _has_pointer_to(self, rom_offset):
        """True if the ROM contains a 4-aligned pointer (0x08xxxxxx) to rom_offset, i.e. code or
        data actually references this table start. Real name tables are referenced; random
        text-like data in front of them (or '?' filler entries) is not."""
        needle = struct.pack("<I", 0x08000000 + rom_offset)
        d = self.data
        pos = 0
        while True:
            i = d.find(needle, pos)
            if i < 0:
                return False
            if i % 4 == 0:
                return True
            pos = i + 1

    def _trim_start(self, start, count, stride, name_len, anchor, window=6):
        """Backward extension may swallow unrelated strings in front of the table (Unbound has
        a text table with the same stride right before the species names). Entry 0 of every
        name table is a placeholder ('?????' / '-'). Among placeholder candidates, prefer the
        first one that the ROM references by pointer; otherwise fall back to the first one
        within `window` entries."""
        d = self.data
        cands = [j for j in range(min(count, 400))
                 if anchor(decode_text(d[start + j * stride: start + j * stride + name_len]))]
        for j in cands:
            if self._has_pointer_to(start + j * stride):
                return start + j * stride, count - j
        for j in cands:
            if j < window:
                return start + j * stride, count - j
        return start, count

    def _find_table(self, stride, name_len, min_count, first_blank=False, validator=None, anchor=None):
        """Find a table of `min_count`+ entries, each `stride` bytes, where every entry
        starts with a terminated Gen3 string that fits in `name_len` bytes (terminator
        included). Returns (offset, count) of the longest run found, or None.
        The run is extended backwards so the true table start is reported."""
        d = self.data
        best = None
        size = len(d)
        off = 0  # tables are 4-aligned in ROM, but we may land mid-table: extend back later
        while off < size - stride * min_count:
            if not is_gen3_text(d[off:off + name_len]):
                off += 4
                continue
            count = 0
            p = off
            while p + stride <= size and is_gen3_text(d[p:p + name_len]):
                count += 1
                p += stride
            if count >= min_count:
                start = off
                # extend backwards to the real start of the table
                while start - stride >= 0 and is_gen3_text(d[start - stride:start - stride + name_len]):
                    start -= stride
                    count += 1
                if anchor is not None:
                    start, count = self._trim_start(start, count, stride, name_len, anchor)
                if validator is None or validator(start, count):
                    if best is None or count > best[1]:
                        best = (start, count)
                off = p - (p % 4) + 4  # skip past this run
            else:
                off += 4
        return best

    def _find_items(self, stride=44, probe=12):
        """Locate the item table by structure: entry i has u16 itemId == i at +14 and a ROM
        pointer (0x08xxxxxx / 0x09xxxxxx) to the description at +20."""
        d = self.data
        size = len(d)
        best = None
        off = 0
        last = size - stride * (probe + 2)
        while off < last:
            # cheap rejects first: id0 == 0 at +14, id1 == 1 at +14+44
            if d[off + 14] == 0 and d[off + 15] == 0 and d[off + stride + 14] == 1 and d[off + stride + 15] == 0:
                ok = True
                for i in range(2, probe):
                    p = off + i * stride
                    if d[p + 14] != (i & 0xFF) or d[p + 15] != (i >> 8) or d[p + 23] not in (0x08, 0x09):
                        ok = False
                        break
                if ok:
                    count = probe
                    # extend while entries still look like item structs (valid text name and a
                    # ROM pointer at +20). The itemId field may jump (hacks reorder ids), so it
                    # is NOT required to equal the index here.
                    while off + (count + 1) * stride <= size:
                        p = off + count * stride
                        if not (d[p + 23] in (0x08, 0x09) and TERM in d[p:p + 14]):
                            break
                        count += 1
                    # drop trailing '?' placeholders (padding, not items)
                    while count > 1:
                        p = off + (count - 1) * stride
                        if set(decode_text(d[p:p + 14])) <= {"?"}:
                            count -= 1
                        else:
                            break
                    if best is None or count > best[1]:
                        best = (off, count)
                    off += count * stride
                    continue
            off += 4
        return best

    def _scan(self):
        d = self.data
        # Species: stride 11, name_len 11. Entry 0 is "??????????" in vanilla; entry 1 "BULBASAUR"
        # (in Gen3 text this is upper case). Expanded hacks keep stride 11 (or 12/13/…).
        # We look for stride 11 first, then others.
        sp = None
        for stride in (11, 12, 13, 14, 16):
            def v(off, count, stride=stride):
                # at least 90% names must be uppercase-ish and contain a letter
                letters = 0
                for i in range(min(count, 400)):
                    s = decode_text(d[off + i * stride: off + i * stride + stride])
                    if s and any(c.isalpha() for c in s):
                        letters += 1
                return letters >= min(count, 400) * 0.8
            r = self._find_table(stride, stride, 250, False, v,
                                 anchor=lambda s: len(s) > 0 and set(s) == {"?"})
            if r:
                sp = (stride, r[0], r[1])
                break
        if sp:
            stride, off, count = sp
            self.species_table_offset = off
            self.species_names = [decode_text(d[off + i * stride: off + i * stride + stride])
                                  for i in range(count)]
            self.notes.append(f"Species table @0x{off:X} ({count} entries, stride {stride})")
        else:
            self.notes.append("Species table not found")

        # Moves: stride 13, ~354 entries
        mv = self._find_table(13, 13, 300,
                              anchor=lambda s: s == "-" or (len(s) > 0 and set(s) == {"?"}))
        if mv:
            off, count = mv
            self.move_table_offset = off
            self.move_names = [decode_text(d[off + i * 13: off + i * 13 + 13]) for i in range(count)]
            self.notes.append(f"Move table @0x{off:X} ({count} entries)")
        else:
            self.notes.append("Move table not found")

        # Items: 44-byte struct {char name[14]; u16 itemId; u16 price; ...; u32 descPtr @20 ...}
        # The itemId field equals the table index -> robust structural signature.
        it = self._find_items()
        if it:
            off, count = it
            self.item_table_offset = off
            self._item_count = count
            # name lookup by the itemId stored in each entry (falls back to the table index when
            # the field is 0), so reordered / expanded tables (e.g. Unbound) resolve correctly
            by_id = {}
            for i in range(count):
                p = off + i * 44
                iid = d[p + 14] | (d[p + 15] << 8)
                nm = decode_text(d[p:p + 14])
                key = iid if iid else i
                if iid or key not in by_id:
                    by_id[key] = nm
            self.item_names = [by_id.get(k, "") for k in range(max(by_id) + 1)]
            self.notes.append(f"Item table @0x{off:X} ({count} entries)")
        else:
            self.notes.append("Item table not found")
        self._scan_variable_stride()
        self._find_item_pockets()
        self._find_move_pp()
        self._find_base_stats()
        self._find_abilities()

    def _scan_variable_stride(self):
        """Fallback for hacks (pokeemerald-expansion) that keep names inside bigger structs: the
        name tables then have an arbitrary stride. Anchor on two consecutive well-known names
        (e.g. Bulbasaur, Ivysaur), take their distance as the stride, check a third name and
        read the table while entries still start with a valid Gen 3 string."""
        import re
        d = self.data

        def find(first, second, third, max_stride=600, min_count=200):
            for casefn in (str.title, str.upper):
                a, b, c = (encode_text(casefn(x), len(x), pad=False) for x in (first, second, third))
                for m in re.finditer(re.escape(a) + rb"\xff", d):
                    p = m.start()
                    seg = d[p + 1:p + 1 + max_stride + len(b) + 2]
                    q = seg.find(b + b"\xff")
                    while q >= 0:
                        stride = q + 1
                        if stride >= 8 and d[p + 2 * stride:p + 2 * stride + len(c) + 1] == c + b"\xff":
                            base = p - stride
                            if base >= 0:
                                names, k = [], 0
                                while base + k * stride + 16 <= len(d) and k < 2500 and is_gen3_text(d[base + k * stride:base + k * stride + min(stride, 24)]):
                                    names.append(decode_text(d[base + k * stride:base + k * stride + min(stride, 24)]))
                                    k += 1
                                if k < min_count and k > 0 and names[-1] and False:
                                    pass
                                if len(names) >= min_count:
                                    return base, stride, names
                        q = seg.find(b + b"\xff", q + 1)
            return None

        if len(self.species_names) < 100:
            r = find("Bulbasaur", "Ivysaur", "Venusaur", min_count=250)
            if r:
                base, stride, names = r
                names[0] = names[0] if names[0] else "??????????"
                self.species_names, self.species_table_offset = names, base
                self.notes.append(f"Species table @0x{base:X} ({len(names)} entries, stride {stride}, anchored)")
        if len(self.move_names) < 100:
            r = find("Pound", "Karate Chop", "Double Slap", min_count=200)
            if r:
                base, stride, names = r
                self.move_names, self.move_table_offset = names, base
                self.notes.append(f"Move table @0x{base:X} ({len(names)} entries, stride {stride}, anchored)")
        if not self.item_names or len(self.item_names) < 100:
            r = find("Master Ball", "Ultra Ball", "Great Ball", min_count=200)
            if r:
                base, stride, names = r
                self.item_names, self.item_table_offset = names, base
                self.notes.append(f"Item table @0x{base:X} ({len(names)} entries, stride {stride}, anchored; no pocket info)")

    # --- sprites ---------------------------------------------------------------
    def _lz_tables(self, lz_size, tag_off, min_total=300):
        """Find tables of 8-byte entries {ptr -> LZ77 blob of lz_size, ..., u16 tag} (the format of
        the front/back picture and palette tables). Entries whose blob does not match (e.g. one
        species with another size) leave gaps, so runs that lie on the same table are merged: for
        them tag difference == address difference / 8. Returns [(start, entries)] of big tables,
        sorted by address; the entry of species i sits at start + 8 * i."""
        import array
        d = self.data
        header = bytes([0x10, lz_size & 0xFF, (lz_size >> 8) & 0xFF, (lz_size >> 16) & 0xFF])
        blobs, o = set(), 0
        while True:
            o = d.find(header, o)
            if o < 0:
                break
            blobs.add(o)
            o += 1
        if not blobs:
            return []
        words = array.array("I")
        words.frombytes(d[: len(d) - len(d) % 4])
        refs = [i * 4 for i, w in enumerate(words) if w - 0x08000000 in blobs]
        runs, cur = [], []
        for pos in refs:
            tag = d[pos + tag_off] | d[pos + tag_off + 1] << 8
            if cur and pos - cur[-1][0] == 8 and tag == cur[-1][1] + 1:
                cur.append((pos, tag))
            else:
                if len(cur) >= 20:
                    runs.append(cur)
                cur = [(pos, tag)]
        if len(cur) >= 20:
            runs.append(cur)
        groups = []
        for run in runs:
            a, t = run[0]
            if groups:
                ga, gt, gend = groups[-1]["start"], groups[-1]["tag0"], groups[-1]["end"]
                if a - gend <= 100 * 8 and (t - gt) * 8 == a - ga:     # same table, index-consistent
                    groups[-1]["end"] = run[-1][0] + 8
                    groups[-1]["n"] += len(run)
                    continue
            groups.append({"start": a, "tag0": t, "end": run[-1][0] + 8, "n": len(run)})
        big = [g for g in groups if g["n"] >= min_total]
        if not big:
            return []
        top = max(g["n"] for g in big)
        # the real species tables are the biggest ones (others are trainer pics, icons, ...)
        return sorted((g["start"], (g["end"] - g["start"]) // 8) for g in big if g["n"] >= 0.8 * top)

    def ensure_gfx(self):
        """Locate the front / back sprite tables (64x64, 4 bpp, LZ77) and the normal / shiny palette
        tables. Scanning a 32 MB ROM takes a few seconds, so it only happens on first use and the
        result is cached with the rest of the ROM info."""
        if self.gfx is not None:
            return self.gfx
        gfx = {}
        sprites = self._lz_tables(0x800, 6)
        pals = self._lz_tables(0x20, 4)
        if sprites:
            gfx["front"] = list(sprites[0])
            if len(sprites) > 1:
                gfx["back"] = list(sprites[1])
        if pals:
            gfx["pal"] = list(pals[0])
            if len(pals) > 1:
                gfx["shiny"] = list(pals[1])
        self.gfx = gfx
        if "back" in gfx:
            # which of the two picture tables is the front one is not fixed (Unbound puts the back
            # pictures first). Back pictures are drawn larger, so the table with fewer opaque
            # pixels over the first species is the front table.
            def opaque(key):
                total = 0
                for sp in range(1, 60):
                    p = self._table_blob(key, sp)
                    px = lz77_decompress(self.data, p) if p is not None else None
                    if px:
                        total += sum(1 for b in px if b & 15) + sum(1 for b in px if b >> 4)
                return total
            if opaque("front") > opaque("back"):
                gfx["front"], gfx["back"] = gfx["back"], gfx["front"]
        if gfx:
            self.notes.append("Sprite tables: " + ", ".join(f"{k} @0x{v[0]:X}" for k, v in gfx.items()))
        if self._cache_file:
            self._save_cache(self._cache_file)
        return gfx

    def _table_blob(self, key, species):
        t = (self.gfx or {}).get(key)
        if not t or not 0 <= species < t[1]:
            return None
        p = t[0] + species * 8
        ptr = struct.unpack_from("<I", self.data, p)[0] - 0x08000000
        if 0 <= ptr < len(self.data) - 4:
            return ptr
        return None

    def sprite_rgba(self, species, shiny=False, back=False):
        """(64, 64, RGBA bytes) of the species' picture, or None when the ROM has none for it."""
        self.ensure_gfx()
        sp = self._table_blob("back" if back else "front", species)
        pl = self._table_blob("shiny" if shiny and "shiny" in self.gfx else "pal", species)
        if sp is None or pl is None:
            return None
        px = lz77_decompress(self.data, sp)
        pal = lz77_decompress(self.data, pl)
        if not px or not pal or len(px) < 0x800 or len(pal) < 32:
            return None
        cols = []
        for v in struct.unpack("<16H", pal[:32]):
            cols.append(((v & 31) * 255 // 31, ((v >> 5) & 31) * 255 // 31, ((v >> 10) & 31) * 255 // 31))
        out = bytearray(64 * 64 * 4)
        for ty in range(8):
            for tx in range(8):
                base = (ty * 8 + tx) * 32
                for y in range(8):
                    for x in range(4):
                        b = px[base + y * 4 + x]
                        for k, n in enumerate((b & 15, b >> 4)):
                            o = ((ty * 8 + y) * 64 + tx * 8 + x * 2 + k) * 4
                            if n:
                                out[o:o + 4] = bytes(cols[n]) + b"\xff"
        return 64, 64, bytes(out)

    def _find_item_pockets(self):
        """Item category per item id, from the pocket byte (+26) of the 44-byte item structs.
        FireRed-based hacks number the pockets Items=1 KeyItems=2 Balls=3 TMs=4 Berries=5,
        Emerald-based ones Items=1 Balls=2 TMs=3 Berries=4 KeyItems=5; Master Ball (id 1) tells
        which numbering is in use."""
        off = self.item_table_offset
        d = self.data
        if off is None or not hasattr(self, "_item_count"):
            return
        n = self.item_table_count = self._item_count
        mb = None
        for i in range(n):
            p = off + i * 44
            if d[p + 14] | (d[p + 15] << 8) == 1:
                mb = d[p + 26]
                break
        enums = {3: {1: "items", 2: "keyitems", 3: "balls", 4: "tms", 5: "berries"},
                 2: {1: "items", 2: "balls", 3: "tms", 4: "berries", 5: "keyitems"}}
        names = enums.get(mb)
        if not names:
            self.notes.append("Item pockets not recognised")
            return
        for i in range(n):
            p = off + i * 44
            iid = d[p + 14] | (d[p + 15] << 8)
            key = names.get(d[p + 26])
            if key and iid and self.item_names[iid:iid + 1] and self.item_names[iid] not in ("", "?" * len(self.item_names[iid])):
                self.item_pockets[iid] = key
        self.notes.append(f"Item pockets for {len(self.item_pockets)} items")

    def items_for_pocket(self, pocket):
        """Item ids that belong into a bag pocket (None when the ROM gave no category info).
        The PC pocket accepts everything except key items."""
        if not self.item_pockets:
            return None
        if pocket == "pc_items":
            return sorted(i for i, k in self.item_pockets.items() if k != "keyitems")
        return sorted(i for i, k in self.item_pockets.items() if k == pocket)

    def _find_base_stats(self):
        """Base-stat table: 28-byte entries {hp,atk,def,spe,spa,spd,type1,type2,catch,exp,ev(2),
        item1(2),item2(2),gender,cycles,friendship,growth,egg1,egg2,ability1,ability2,...}.
        Anchored on Bulbasaur's stats (45/49/49/45/65/65, Grass/Poison, catch 45) and validated
        over the first 251 species."""
        import re
        d = self.data
        n = len(self.species_names)
        if n < 100:
            return
        for m in re.finditer(rb"\x2d\x31\x31\x2d\x41\x41\x0c\x03\x2d", d):
            base = m.start() - 28
            if base < 0 or base % 4 or base + n * 28 > len(d):
                continue
            ok = 0
            for k in range(1, min(n, 252)):
                e = base + k * 28
                if 0 < max(d[e:e + 6]) and d[e + 19] <= 5 and d[e + 6] < 0x20 and d[e + 7] < 0x20:
                    ok += 1
            if ok < min(n - 1, 251) * 0.97:
                continue
            self.base_stats_offset = base
            self.species_stats = []
            for k in range(n):
                e = base + k * 28
                if e + 28 > len(d):
                    break
                self.species_stats.append(list(d[e:e + 6]) + [d[e + 16], d[e + 19], d[e + 22], d[e + 23],
                                                              d[e + 26] if e + 26 < len(d) else 0])
            self.notes.append(f"Base-stat table @0x{base:X}")
            return
        self.notes.append("Base-stat table not found")

    def _find_abilities(self):
        """Ability name table (13-byte entries, entry 1 = Stench, entry 2 = Drizzle)."""
        import re
        d = self.data
        best = None
        for a, b in (("STENCH", "DRIZZLE"), ("Stench", "Drizzle")):
            ea, eb = encode_text(a, 6, pad=False), encode_text(b, 7, pad=False)
            for m in re.finditer(re.escape(ea) + rb"\xff", d):
                # the stride is not fixed (13 in vanilla, 17 in Unbound): find entry 2 after it
                for stride in range(13, 25):
                    base = m.start() - stride
                    if base < 0 or base % 4 or d[base + 2 * stride:base + 2 * stride + len(eb)] != eb:
                        continue
                    names = []
                    p = base
                    while p + stride <= len(d) and is_gen3_text(d[p:p + stride]) and len(names) < 400:
                        names.append(decode_text(d[p:p + stride]))
                        p += stride
                    if len(names) > 60 and (best is None or len(names) > len(best[1])):
                        best = (base, names, stride)
        if best:
            self.ability_table_offset, self.ability_names = best[0], best[1]
            self.notes.append(f"Ability table @0x{best[0]:X} ({len(best[1])} entries, stride {best[2]})")
            return
        self.notes.append("Ability table not found")

    def species_info(self, i):
        """dict(base=[6], gender=ratio, growth=0..5, abilities=[a1,a2,hidden]) or None."""
        if 0 <= i < len(self.species_stats):
            s = self.species_stats[i]
            return {"base": s[:6], "gender": s[6], "growth": s[7], "abilities": s[8:11]}
        return None

    def ability(self, i):
        if 0 <= i < len(self.ability_names) and self.ability_names[i]:
            return self.ability_names[i]
        return f"Ability {i}"

    def _find_move_pp(self):
        """Locate the battle-move table (12-byte entries: effect, power, type, accuracy, pp, ...)
        by the signature of move 1 (Pound: power 40, Normal, 100 acc, 35 PP), then validate
        the whole table (plausible PP everywhere, Thunderbolt = Electric / 15 PP)."""
        import re
        d = self.data
        n = len(self.move_names)
        if n < 100:
            return
        cnt = min(n, 300)
        for m in re.finditer(rb".\x28\x00\x64\x23", d, re.S):
            base = m.start() - 12
            if base < 0 or base % 4 or base + n * 12 > len(d):
                continue
            ok = sum(1 for k in range(1, cnt) if 0 < d[base + k * 12 + 4] <= 64)
            if ok < (cnt - 1) * 0.97:
                continue
            if cnt > 85 and not (d[base + 85 * 12 + 2] == 13 and d[base + 85 * 12 + 4] == 15):
                continue
            self.move_pp_offset = base
            self.move_pps = [d[base + k * 12 + 4] for k in range(n)]
            self.notes.append(f"Move PP table @0x{base:X}")
            return
        self.notes.append("Move PP table not found")

    def move_pp(self, i):
        return self.move_pps[i] if 0 <= i < len(self.move_pps) else 0

    def species(self, i):
        if 0 <= i < len(self.species_names) and self.species_names[i]:
            return self.species_names[i]
        return fallback_species(i)

    def item(self, i):
        if i == 0:
            return "(none)"
        if 0 <= i < len(self.item_names) and self.item_names[i]:
            return self.item_names[i]
        return fallback_item(i)

    def move(self, i):
        if 0 <= i < len(self.move_names) and self.move_names[i]:
            return self.move_names[i]
        return fallback_move(i)


# ----------------------------------------------------------------------------
# Save file
# ----------------------------------------------------------------------------
SECTION_SIZE = 0x1000
SECTION_COUNT = 14
SLOT_SIZE = SECTION_SIZE * SECTION_COUNT
SIGNATURE = 0x08012025
UNBOUND_SIGNATURE = 0x01121998
UNBOUND_SIGNATURES = (0x01121998, 0x01121999, 0x01122000)
EMERALD_LEGACY = "EmeraldLegacy"                    # Emerald with a 120-slot item pocket (Pokémon Emerald Legacy)
UNBOUND, RADICAL_RED = "Unbound", "RadicalRed"      # CFRU-based layouts (values for SaveFile(game=...))
RADICAL_RED_SIGNATURE = 0x08012025                 # same as vanilla FireRed -> needs extra checks
CFRU_NAMES = {UNBOUND: "Pokémon Unbound", RADICAL_RED: "Pokémon Radical Red"}
# Pokemon Unbound layout. Source: the PUSE save editor (Zannael/PUSE, MIT licence) - game profile
# "unbound-2.1.1.1" - cross-checked against real saves (checksums, party, PC, bag all decode
# to sensible data with names read from the ROM).
# Checksums cover only part of sections 0, 4 and 13; every other section covers 4080 bytes.
UNBOUND_WINDOWS = {0: 3876, 4: 3480, 13: 1104}
UNBOUND_DEFAULT_WINDOW = 4080
UNBOUND_OPAQUE = {4}          # never verified / rewritten
# PC storage = concatenation of these regions: (section, start, end). Section ids below 14 are
# logical sections of the active slot, 30 / 31 are physical auxiliary sectors (absolute offset
# id * 4096). 720 records of 58 bytes = 24 boxes x 30 slots.
UNBOUND_PC_REGIONS = ([(5, 4, 4080)] + [(i, 0, 4080) for i in range(6, 13)]
                      + [(13, 0, 424), (30, 2828, 4080), (31, 0, 3968), (2, 3864, 4080), (3, 0, 3264)])
UNBOUND_BOXES, UNBOUND_BOX_SLOTS, UNBOUND_PC_RECORD = 24, 30, 58
# Bag pockets: (section, start offset, hard end offset); 4-byte slots {u16 item, u16 quantity}
# terminated by item 0, no encryption.
UNBOUND_BAG = {"keyitems": (30, 496, 796), "balls": (30, 796, 996), "tms": (30, 996, 1508),
               "berries": (30, 1508, 2828), "items": (13, 2776, 4080)}
SECTION_DATA_SIZE = [3884, 3968, 3968, 3968, 3848, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 3968, 2000]

RS, FRLG, EMERALD = "RS", "FRLG", "Emerald"


def checksum(data):
    s = 0
    for i in range(0, len(data) - len(data) % 4, 4):
        s = (s + struct.unpack_from("<I", data, i)[0]) & 0xFFFFFFFF
    return ((s >> 16) + (s & 0xFFFF)) & 0xFFFF


# ----------------------------------------------------------------------------
# Pokemon maths: natures, growth curves, stats, PID solving
# ----------------------------------------------------------------------------
NATURES = ["Hardy", "Lonely", "Brave", "Adamant", "Naughty", "Bold", "Docile", "Relaxed", "Impish",
           "Lax", "Timid", "Hasty", "Serious", "Jolly", "Naive", "Modest", "Mild", "Quiet", "Bashful",
           "Rash", "Calm", "Gentle", "Sassy", "Careful", "Quirky"]
STAT_NAMES = ["HP", "Atk", "Def", "Spe", "SpA", "SpD"]    # order used inside the save data
GROWTH_NAMES = ["Medium Fast", "Erratic", "Fluctuating", "Medium Slow", "Fast", "Slow"]


def nature_effect(nature):
    """(increased stat index, decreased stat index) in STAT_NAMES order; equal when neutral."""
    order = [1, 2, 3, 4, 5]   # Atk, Def, Spe, SpA, SpD
    return order[(nature // 5) % 5], order[nature % 5]


def calc_stats(base6, ivs, evs, level, nature):
    """Gen 3 stat formula. Everything in STAT_NAMES order. Returns [HP, Atk, Def, Spe, SpA, SpD]."""
    up, down = nature_effect(nature)
    out = []
    for i in range(6):
        core = (2 * base6[i] + ivs[i] + evs[i] // 4) * level // 100
        if i == 0:
            out.append(1 if base6[0] == 1 else core + level + 10)   # Shedinja
        else:
            v = core + 5
            if up != down and i == up:
                v = v * 110 // 100
            elif up != down and i == down:
                v = v * 90 // 100
            out.append(v)
    return out


def exp_for_level(rate, n):
    """Experience needed for level n with growth rate 0..5 (Gen 3 numbering)."""
    c = n ** 3
    if rate == 0:
        return c
    if rate == 1:      # erratic
        if n <= 50:
            return c * (100 - n) // 50
        if n <= 68:
            return c * (150 - n) // 100
        if n <= 98:
            return c * ((1911 - 10 * n) // 3) // 500
        return c * (160 - n) // 100
    if rate == 2:      # fluctuating
        if n <= 15:
            return c * (((n + 1) // 3) + 24) // 50
        if n <= 35:
            return c * (n + 14) // 50
        return c * ((n // 2) + 32) // 50
    if rate == 3:      # medium slow
        return max(0, 6 * c // 5 - 15 * n * n + 100 * n - 140)
    if rate == 4:
        return 4 * c // 5
    return 5 * c // 4


def level_from_exp(rate, exp):
    lvl = 1
    for n in range(2, 101):
        if exp >= exp_for_level(rate, n):
            lvl = n
        else:
            break
    return lvl


def gender_of(pid, ratio):
    """0 male, 1 female, 2 genderless; None when the species ratio is unknown."""
    if ratio is None:
        return None
    if ratio == 255:
        return 2
    if ratio == 254:
        return 1
    if ratio == 0:
        return 0
    return 1 if (pid & 0xFF) < ratio else 0


def is_shiny_pid(pid, otid, threshold):
    return ((otid & 0xFFFF) ^ (otid >> 16) ^ (pid >> 16) ^ (pid & 0xFFFF)) < threshold


def solve_pid(pid, otid, nature, parity, shiny, ratio, threshold):
    """Find the PID closest to `pid` that has the wanted nature (pid % 25), ability parity
    (pid & 1) and shininess while keeping the gender (decided by the lowest PID byte).
    Works by fixing the low byte (changing it only when the parity must flip) and walking the
    upper 24 bits in steps of 25 (which keeps the nature) until the shiny state matches."""
    def ok(p):
        return p % 25 == nature and (p & 1) == parity and is_shiny_pid(p, otid, threshold) == shiny
    if ok(pid):
        return pid
    lo8 = pid & 0xFF
    if (pid & 1) != parity:
        g = gender_of(pid, ratio)
        cands = sorted((v for v in range(256) if (v & 1) == parity
                        and (ratio is None or gender_of((pid & ~0xFF) | v, ratio) == g)),
                       key=lambda v: abs(v - lo8))
        lo8 = cands[0] if cands else lo8 ^ 1
    h0 = pid >> 8
    d = ((nature - lo8) * 21) % 25          # 256 = 6 (mod 25) and 6 * 21 = 1 (mod 25)
    start = h0 - (h0 % 25) + d
    for k in range(0, (1 << 24) // 25 + 1):
        for sign in ((1,) if k == 0 else (1, -1)):
            h = start + sign * 25 * k
            if 0 <= h < (1 << 24):
                p = (h << 8) | lo8
                if ok(p):
                    return p
    return pid


class MonExtras:
    """IV / EV / nature / ability / shiny / stat helpers shared by every record type.
    Subclasses provide: pid (get/set), otid, _iv_word / _set_iv_word, _get_evs / _set_evs,
    happiness (get/set), raw (bytearray), is_party, SHINY_THRESHOLD, ABILITY_BY_PID."""
    SHINY_THRESHOLD = 8
    ABILITY_BY_PID = False
    ABILITY_SLOTS = 2
    HAS_BALL = False

    @property
    def ivs(self):
        w = self._iv_word()
        return [(w >> (5 * i)) & 31 for i in range(6)]

    @ivs.setter
    def ivs(self, vals):
        w = self._iv_word() & 0xC0000000
        for i in range(6):
            w |= (max(0, min(31, int(vals[i]))) & 31) << (5 * i)
        self._set_iv_word(w)

    @property
    def evs(self):
        return list(self._get_evs())

    @evs.setter
    def evs(self, vals):
        self._set_evs([max(0, min(255, int(v))) for v in vals])

    @property
    def nature(self):
        return self.pid % 25

    @property
    def hidden_ability(self):
        return bool((self._iv_word() >> 31) & 1)

    @property
    def ability_slot(self):
        """0 / 1 = first / second ability, 2 = hidden ability (Unbound only)."""
        if self.ABILITY_BY_PID:
            return 2 if self.hidden_ability else (self.pid & 1)
        return 1 if self.hidden_ability else 0

    @property
    def is_shiny(self):
        return is_shiny_pid(self.pid, self.otid, self.SHINY_THRESHOLD)

    def gender(self, ratio):
        return gender_of(self.pid, ratio)

    def set_identity(self, nature=None, ability_slot=None, shiny=None, ratio=None):
        """Change nature / ability slot / shininess. The PID is only touched when needed and then
        in a way that keeps the gender (see solve_pid)."""
        pid = self.pid
        nature = self.nature if nature is None else nature
        shiny = self.is_shiny if shiny is None else shiny
        slot = self.ability_slot if ability_slot is None else ability_slot
        w = self._iv_word()
        if self.ABILITY_BY_PID:
            hidden = slot == 2
            parity = (pid & 1) if hidden else slot
        else:
            hidden = bool(slot)
            parity = pid & 1
        w = (w | 0x80000000) if hidden else (w & 0x7FFFFFFF)
        self._set_iv_word(w)
        new = solve_pid(pid, self.otid, nature, parity, shiny, ratio, self.SHINY_THRESHOLD)
        if new != pid:
            self.pid = new

    def recalc_stats(self, base6):
        """Recompute the party stats (current / max HP, Atk, Def, Spe, SpA, SpD) from the ROM's
        base stats. Current HP keeps full / the same missing fraction."""
        if not self.is_party or not base6:
            return
        lvl = self.level
        new = calc_stats(base6, self.ivs, self.evs, lvl, self.nature)
        old_cur, old_max = struct.unpack_from("<HH", self.raw, 86)
        cur = new[0] if old_cur >= old_max or old_max == 0 else min(new[0], old_cur)
        struct.pack_into("<H", self.raw, 86, cur)
        for i in range(6):
            struct.pack_into("<H", self.raw, 88 + i * 2, new[i])


class Pokemon(MonExtras):
    """Decrypted Gen3 Pokemon (80 byte box / 100 byte party)."""
    ORDERS = ["GAEM", "GAME", "GEAM", "GEMA", "GMAE", "GMEA", "AGEM", "AGME", "AEGM",
              "AEMG", "AMGE", "AMEG", "EGAM", "EGMA", "EAGM", "EAMG", "EMGA", "EMAG",
              "MGAE", "MGEA", "MAGE", "MAEG", "MEGA", "MEAG"]

    def __init__(self, raw):
        self.raw = bytearray(raw)
        self.is_party = len(raw) >= 100
        self._pid = struct.unpack_from("<I", self.raw, 0)[0]
        self.otid = struct.unpack_from("<I", self.raw, 4)[0]
        self.nickname_raw = bytes(self.raw[8:18])
        self.ot_raw = bytes(self.raw[20:27])
        key = self.pid ^ self.otid
        enc = self.raw[32:80]
        dec = bytearray(48)
        for i in range(0, 48, 4):
            v = struct.unpack_from("<I", enc, i)[0] ^ key
            struct.pack_into("<I", dec, i, v)
        order = self.ORDERS[self.pid % 24]
        self.blocks = {}
        for idx, ch in enumerate(order):
            self.blocks[ch] = bytearray(dec[idx * 12:(idx + 1) * 12])
        self.order = order
        # checksum of the 48 data bytes must match the stored one (else: bad egg / garbage)
        cs = 0
        for i in range(0, 48, 2):
            cs = (cs + struct.unpack_from("<H", dec, i)[0]) & 0xFFFF
        self.valid = cs == struct.unpack_from("<H", self.raw, 28)[0]

    @property
    def pid(self):
        return self._pid

    @pid.setter
    def pid(self, v):
        v &= 0xFFFFFFFF
        self._pid = v
        self.order = self.ORDERS[v % 24]       # block order and encryption key follow the PID
        struct.pack_into("<I", self.raw, 0, v)

    # hooks for MonExtras (blocks: G growth, A attacks, E EVs/condition, M misc)
    def _iv_word(self):
        return struct.unpack_from("<I", self.blocks["M"], 4)[0]

    def _set_iv_word(self, v):
        struct.pack_into("<I", self.blocks["M"], 4, v & 0xFFFFFFFF)

    def _get_evs(self):
        return list(self.blocks["E"][0:6])

    def _set_evs(self, vals):
        self.blocks["E"][0:6] = bytes(vals)

    @property
    def happiness(self):
        return self.blocks["G"][9]

    @happiness.setter
    def happiness(self, v):
        self.blocks["G"][9] = max(0, min(255, int(v)))

    @property
    def empty(self):
        return self.pid == 0 and self.species == 0

    @property
    def species(self):
        return struct.unpack_from("<H", self.blocks["G"], 0)[0]

    @species.setter
    def species(self, v):
        struct.pack_into("<H", self.blocks["G"], 0, v)

    @property
    def held_item(self):
        return struct.unpack_from("<H", self.blocks["G"], 2)[0]

    @held_item.setter
    def held_item(self, v):
        struct.pack_into("<H", self.blocks["G"], 2, v)

    @property
    def exp(self):
        return struct.unpack_from("<I", self.blocks["G"], 4)[0]

    @exp.setter
    def exp(self, v):
        struct.pack_into("<I", self.blocks["G"], 4, v)

    @property
    def moves(self):
        return list(struct.unpack_from("<4H", self.blocks["A"], 0))

    def set_move(self, i, v):
        struct.pack_into("<H", self.blocks["A"], i * 2, v)

    @property
    def pp(self):
        return list(self.blocks["A"][8:12])

    @property
    def level(self):
        return self.raw[84] if self.is_party else 0

    @level.setter
    def level(self, v):
        if self.is_party:
            self.raw[84] = v

    @property
    def nickname(self):
        return decode_text(self.nickname_raw)

    @nickname.setter
    def nickname(self, s):
        self.nickname_raw = encode_text(s, 10)

    @property
    def ot_name(self):
        return decode_text(self.ot_raw)

    def to_bytes(self):
        out = bytearray(self.raw)
        # recompute checksum of the 48 bytes
        dec = bytearray(48)
        for idx, ch in enumerate(self.order):
            dec[idx * 12:(idx + 1) * 12] = self.blocks[ch]
        cs = 0
        for i in range(0, 48, 2):
            cs = (cs + struct.unpack_from("<H", dec, i)[0]) & 0xFFFF
        struct.pack_into("<H", out, 28, cs)
        out[8:18] = self.nickname_raw
        out[20:27] = self.ot_raw
        key = self.pid ^ self.otid
        for i in range(0, 48, 4):
            v = struct.unpack_from("<I", dec, i)[0] ^ key
            struct.pack_into("<I", out, 32 + i, v)
        return bytes(out)



class UnboundMon(MonExtras):
    """Pokemon record of Pokemon Unbound (CFRU engine). Unlike vanilla Gen 3 these records are
    NOT encrypted. Party records are 100 bytes (sub-structures B, A, D, C in that fixed order
    from offset 32); PC records are a compact 58 bytes with 10-bit move ids.
    `move_pp_lookup` may be set to a function move_id -> base PP (read from the ROM)."""
    move_pp_lookup = None
    is_party = False
    SIZE = 0
    SHINY_THRESHOLD = 16       # PUSE game profile: shiny_threshold 16
    ABILITY_BY_PID = True      # ability = PID parity (+ hidden-ability flag)
    ABILITY_SLOTS = 3
    HAS_BALL = True

    def __init__(self, raw):
        self.raw = bytearray(raw[:self.SIZE])

    # shared fields -----------------------------------------------------------
    @property
    def pid(self):
        return struct.unpack_from("<I", self.raw, 0)[0]

    @pid.setter
    def pid(self, v):
        struct.pack_into("<I", self.raw, 0, v & 0xFFFFFFFF)

    @property
    def otid(self):
        return struct.unpack_from("<I", self.raw, 4)[0]

    @property
    def nickname(self):
        return decode_text(self.raw[8:18])

    @nickname.setter
    def nickname(self, s):
        self.raw[8:18] = encode_text(s, 10)

    @property
    def ot_name(self):
        return decode_text(self.raw[20:27])

    @property
    def happiness(self):
        return self.raw[self.O_HAPPY]

    @happiness.setter
    def happiness(self, v):
        self.raw[self.O_HAPPY] = max(0, min(255, int(v)))

    @property
    def ball(self):
        return self.raw[self.O_BALL]

    @ball.setter
    def ball(self, v):
        self.raw[self.O_BALL] = max(0, min(255, int(v)))

    @property
    def empty(self):
        return self.species == 0

    def to_bytes(self):
        return bytes(self.raw)


class UnboundPartyMon(UnboundMon):
    SIZE = 100
    is_party = True
    O_SPECIES, O_ITEM, O_EXP, O_MOVES, O_PP = 32, 34, 36, 44, 52
    O_IV, O_EV, O_HAPPY, O_BALL = 72, 56, 41, 42

    def _iv_word(self):
        return struct.unpack_from("<I", self.raw, self.O_IV)[0]

    def _set_iv_word(self, v):
        struct.pack_into("<I", self.raw, self.O_IV, v & 0xFFFFFFFF)

    def _get_evs(self):
        return list(self.raw[self.O_EV:self.O_EV + 6])

    def _set_evs(self, vals):
        self.raw[self.O_EV:self.O_EV + 6] = bytes(vals)

    @property
    def species(self):
        return struct.unpack_from("<H", self.raw, self.O_SPECIES)[0]

    @species.setter
    def species(self, v):
        struct.pack_into("<H", self.raw, self.O_SPECIES, v)

    @property
    def held_item(self):
        return struct.unpack_from("<H", self.raw, self.O_ITEM)[0]

    @held_item.setter
    def held_item(self, v):
        struct.pack_into("<H", self.raw, self.O_ITEM, v)

    @property
    def exp(self):
        return struct.unpack_from("<I", self.raw, self.O_EXP)[0]

    @exp.setter
    def exp(self, v):
        struct.pack_into("<I", self.raw, self.O_EXP, v & 0xFFFFFFFF)

    @property
    def moves(self):
        return list(struct.unpack_from("<4H", self.raw, self.O_MOVES))

    def set_move(self, i, v):
        old = self.moves[i]
        struct.pack_into("<H", self.raw, self.O_MOVES + i * 2, v)
        if v != old:
            pp = 0
            if v and self.move_pp_lookup:
                pp = self.move_pp_lookup(v) or 0
            self.raw[self.O_PP + i] = pp if v else 0

    @property
    def pp(self):
        return list(self.raw[self.O_PP:self.O_PP + 4])

    @property
    def level(self):
        return self.raw[84]

    @level.setter
    def level(self, v):
        self.raw[84] = max(1, min(100, v))

    @property
    def valid(self):
        return 0 < self.species <= 2500 and 1 <= self.raw[84] <= 100

    def to_bytes(self):
        out = bytearray(self.raw)
        struct.pack_into("<H", out, 28, 0)   # runtime-substitution field must stay 0 (see PUSE)
        return bytes(out)


class UnboundBoxMon(UnboundMon):
    SIZE = 58
    O_SPECIES, O_ITEM, O_EXP = 28, 30, 32
    O_IV, O_EV, O_HAPPY, O_BALL = 54, 44, 37, 38

    def _iv_word(self):
        return struct.unpack_from("<I", self.raw, self.O_IV)[0]

    def _set_iv_word(self, v):
        struct.pack_into("<I", self.raw, self.O_IV, v & 0xFFFFFFFF)

    def _get_evs(self):
        return list(self.raw[self.O_EV:self.O_EV + 6])

    def _set_evs(self, vals):
        self.raw[self.O_EV:self.O_EV + 6] = bytes(vals)

    @property
    def species(self):
        return struct.unpack_from("<H", self.raw, self.O_SPECIES)[0]

    @species.setter
    def species(self, v):
        struct.pack_into("<H", self.raw, self.O_SPECIES, v)

    @property
    def held_item(self):
        return struct.unpack_from("<H", self.raw, self.O_ITEM)[0]

    @held_item.setter
    def held_item(self, v):
        struct.pack_into("<H", self.raw, self.O_ITEM, v)

    @property
    def exp(self):
        return struct.unpack_from("<I", self.raw, self.O_EXP)[0]

    @exp.setter
    def exp(self, v):
        struct.pack_into("<I", self.raw, self.O_EXP, v & 0xFFFFFFFF)

    def _packed_moves(self):
        return int.from_bytes(self.raw[0x27:0x2C], "little")

    @property
    def moves(self):
        p = self._packed_moves()
        return [(p >> (10 * k)) & 0x3FF for k in range(4)]

    def set_move(self, i, v):
        p = self._packed_moves()
        p &= ~(0x3FF << (10 * i))
        p |= (v & 0x3FF) << (10 * i)
        self.raw[0x27:0x2C] = p.to_bytes(5, "little")

    @property
    def pp(self):
        return [0, 0, 0, 0]       # compact PC records keep no current PP

    @property
    def level(self):
        return 0                   # derived from exp + growth rate by the game

    @property
    def valid(self):
        return 0 < self.species <= 2500 and 0 < self.exp <= 2_000_000


class PartyOps:
    """add / remove party members (needs party_count, _party_off, set_party_member, data)."""

    def add_party_member(self, mon):
        n = self.party_count
        if n >= 6:
            raise ValueError("The party is full (6 Pokémon)")
        self.set_party_member(n, mon)
        self.party_count = n + 1
        return n

    def remove_party_member(self, i):
        n = self.party_count
        if not 0 <= i < n:
            return
        base = self._party_off()
        for j in range(i, n - 1):
            self.data[base + j * 100: base + j * 100 + 100] = self.data[base + (j + 1) * 100: base + (j + 2) * 100]
        self.data[base + (n - 1) * 100: base + n * 100] = bytes(100)
        self.party_count = n - 1


class SaveFile(PartyOps):
    def __init__(self, data, game=None):
        if len(data) < SLOT_SIZE * 2:
            raise ValueError("Save too small (expected >= 128 KB)")
        self.data = bytearray(data)
        self._orig = bytes(data)
        self.unfixable = []
        self.slot_offset = None
        self.sections = {}      # section id -> absolute offset
        self.game = RS
        self.security_key = 0
        self._force = game if game in (UNBOUND, RADICAL_RED) else ("none" if game in (RS, FRLG, EMERALD, EMERALD_LEGACY) else None)
        self.cfru = None
        self._find_active_slot()
        self.hack = CFRU_NAMES.get(self.cfru, "")
        self.shiny_threshold = 8 if self.cfru == RADICAL_RED else 16
        if self.is_unbound:
            # Unbound is a FireRed hack: same trainer block, unencrypted (security key 0)
            self._set_game(FRLG)
            self.security_key = 0       # CFRU saves store money/quantities unencrypted
            self.detect_scores = {}
        elif game in (RS, FRLG, EMERALD):
            self._set_game(game)
            self.detect_scores = {}
        elif game == EMERALD_LEGACY:
            self._set_game(EMERALD)
            self.detect_scores = {}
        else:
            self._detect_game()
        self.legacy = game == EMERALD_LEGACY or (game is None and self.game == EMERALD and self._detect_legacy())
        if self.legacy:
            self.hack = "Pokémon Emerald Legacy"

    # --- slot handling ---------------------------------------------------------
    def _slot_info(self, base):
        """Validate one 14-section slot. The signature is learned from the file (vanilla
        is 0x08012025, Pokemon Unbound uses 0x01121998) - it only has to be identical in
        all 14 sections. Sections may be stored rotated; we map section id -> offset."""
        ids = {}
        sigs = set()
        counters = []
        for i in range(SECTION_COUNT):
            off = base + i * SECTION_SIZE
            sid, = struct.unpack_from("<H", self.data, off + 0xFF4)
            sig, cnt = struct.unpack_from("<II", self.data, off + 0xFF8)
            if sig in (0, 0xFFFFFFFF) or sid >= SECTION_COUNT:
                return None, -1, None
            ids[sid] = off
            sigs.add(sig)
            counters.append(cnt)
        if len(ids) != SECTION_COUNT or not (len(sigs) == 1 or sigs <= set(UNBOUND_SIGNATURES)):
            return None, -1, None
        return ids, max(counters), min(sigs)

    def _find_active_slot(self):
        a, ca, sa = self._slot_info(0)
        b, cb, sb = self._slot_info(SLOT_SIZE)
        if a is None and b is None:
            raise ValueError("No valid Gen3 save slot found (no 14 sections with a common signature)")
        if b is None or (a is not None and ca >= cb):
            self.sections, self.slot_offset, self.counter, self.signature = a, 0, ca, sa
        else:
            self.sections, self.slot_offset, self.counter, self.signature = b, SLOT_SIZE, cb, sb
        self.cfru = self._detect_cfru()
        # Work out which data size each section's checksum covers. Vanilla uses the table
        # SECTION_DATA_SIZE; expanded hacks (Pokemon Unbound) cover the full 0xFF4 bytes.
        self.sect_size = {}
        self.bad_sections = []     # sections where no known size reproduces the stored checksum
        self.nonstandard = False   # True if any section deviates from the vanilla sizes
        for sid, off in self.sections.items():
            stored, = struct.unpack_from("<H", self.data, off + 0xFF6)
            chosen = None
            if self.is_unbound and sid in UNBOUND_OPAQUE:
                # PUSE treats this section as opaque: do not verify it, do not rewrite it
                self.sect_size[sid] = UNBOUND_WINDOWS.get(sid, UNBOUND_DEFAULT_WINDOW)
                self.nonstandard = True
                continue
            known = [SECTION_DATA_SIZE[sid]]
            if self.is_unbound:
                known = [UNBOUND_WINDOWS.get(sid, UNBOUND_DEFAULT_WINDOW)] + known
            for n in known:
                if checksum(self.data[off:off + n]) == stored:
                    chosen = n
                    break
            if chosen is None:
                # brute force: the checksum is a running 32-bit word sum, so test every
                # candidate end offset with prefix sums; take the largest match
                s = 0
                matches = []
                first_nz = None   # a match inside the leading zero words is meaningless
                for w in range(0, 0xFF4 // 4):
                    word = struct.unpack_from("<I", self.data, off + w * 4)[0]
                    if word and first_nz is None:
                        first_nz = (w + 1) * 4
                    s = (s + word) & 0xFFFFFFFF
                    if first_nz is not None and (((s >> 16) + (s & 0xFFFF)) & 0xFFFF) == stored:
                        matches.append((w + 1) * 4)
                if matches:
                    chosen = matches[0]
            if chosen is None:
                self.bad_sections.append(sid)
                chosen = SECTION_DATA_SIZE[sid]
            if chosen != SECTION_DATA_SIZE[sid]:
                self.nonstandard = True
            self.sect_size[sid] = chosen

    def sec(self, sid):
        return self.sections[sid]

    def _party_off(self):
        return self._inv_base() + self._layout()["party"]

    def _detect_cfru(self):
        """Which CFRU layout (if any) this save uses. Unbound has its own signatures. Radical Red
        keeps FireRed's signature: it writes 1 at 0xAC like FireRed, but its security key (0xF20)
        is zero or out of sync with the copy at 0xAF8, which vanilla FireRed keeps equal."""
        if self._force in (UNBOUND, RADICAL_RED):
            return self._force
        if self.signature in UNBOUND_SIGNATURES:
            return UNBOUND           # unambiguous signature: also kept when a vanilla layout was picked
        if self._force != "none" and self.signature == RADICAL_RED_SIGNATURE:
            o = self.sections[0]
            game_code, = struct.unpack_from("<I", self.data, o + 0xAC)
            key, = struct.unpack_from("<I", self.data, o + 0xF20)
            copy, = struct.unpack_from("<I", self.data, o + 0xAF8)
            if game_code == 1 and (key == 0 or key != copy):
                return RADICAL_RED
        return None

    @property
    def is_unbound(self):
        """True for any CFRU layout (Unbound, Radical Red); name kept for compatibility."""
        return self.cfru is not None

    is_cfru = is_unbound

    # --- game detection --------------------------------------------------------
    def _set_game(self, game):
        self.game = game
        o = self.sec(0)
        if game == EMERALD:
            self.security_key = struct.unpack_from("<I", self.data, o + 0xAC)[0]
        elif game == FRLG:
            self.security_key = struct.unpack_from("<I", self.data, o + 0xF20)[0]
        else:
            self.security_key = 0

    def _score_game(self):
        """Plausibility score of the currently set layout: valid party Pokemon (checksum),
        sane party count and sane (decrypted) money."""
        L = self._layout()
        b = self._inv_base()
        score = 0
        n, = struct.unpack_from("<I", self.data, b + L["party_cnt"])
        if 0 <= n <= 6:
            score += 1
            for i in range(n):
                o = b + L["party"] + i * 100
                m = Pokemon(self.data[o:o + 100])
                if m.valid and 0 < m.species < 2000 and 0 < m.level <= 100:
                    score += 3
        if self.money <= 999999:
            score += 2
        return score

    def _detect_game(self):
        """Try all three layouts and keep the most plausible one. The 'game code' field at
        0xAC is only used as a tie-break hint (some saves have 0xFFFFFFFF there)."""
        o = self.sec(0)
        code, = struct.unpack_from("<I", self.data, o + 0xAC)
        hint = RS if code == 0 else FRLG if code == 1 else EMERALD
        self.detect_scores = {}
        best, best_score = None, -1
        for g in (hint, RS, FRLG, EMERALD):
            if g in self.detect_scores:
                continue
            self._set_game(g)
            self.detect_scores[g] = self._score_game()
            if self.detect_scores[g] > best_score:
                best, best_score = g, self.detect_scores[g]
        self._set_game(best)

    # section 1 layout (team/items)
    def _detect_legacy(self):
        """Emerald Legacy (items pocket 30 -> 120 slots) keeps Emerald's signature. Told apart by
        the Pokédex 'seen' flags, which the game writes in three copies: they agree at Legacy's
        offsets and disagree at Emerald's, and the pouches look sane at Legacy's offsets."""
        try:
            small = bytes(self.data[self.sec(0):self.sec(0) + 0xF80])
            large = b"".join(bytes(self.data[self.sec(i):self.sec(i) + 0xF80]) for i in range(1, 5))
            same = lambda a, b: large[a:a + 0x34] == large[b:b + 0x34]
            if not same(0xAF0, 0x3B34) or same(0x988, 0x3B24):
                return False
            key = struct.unpack_from("<I", small, 0xAC)[0] & 0xFFFF
            used_keys = 0
            for off, slots, mx in ((0x740, 30, 1), (0x8F8, 46, 999), (0x7F8, 64, 99)):
                for i in range(slots):
                    iid, qty = struct.unpack_from("<HH", large, off + i * 4)
                    if iid == 0:
                        continue
                    q = qty ^ key
                    if q == 0 or q > mx:
                        return False
                    if off == 0x740:
                        used_keys += 1
            return used_keys > 0
        except Exception:
            return False

    LEGACY_QTY = {"pc_items": 999, "items": 99, "keyitems": 1, "balls": 99, "tms": 99, "berries": 999}

    def pocket_qty_max(self, pocket):
        if getattr(self, "legacy", False):
            return self.LEGACY_QTY.get(pocket, 99)
        if self.cfru:
            return 1 if pocket == "tms" else 999
        return {"keyitems": 1, "tms": 99}.get(pocket, 999)

    def _layout(self):
        g = self.game
        if getattr(self, "legacy", False):
            return dict(party_cnt=0x234, party=0x238, money=0x490, coins=0x494,
                        pc_items=(0x498, 50), items=(0x560, 120), keyitems=(0x740, 30),
                        balls=(0x7B8, 16), tms=(0x7F8, 64), berries=(0x8F8, 46))
        if g == RS:
            return dict(party_cnt=0x234, party=0x238, money=0x490, coins=0x494,
                        pc_items=(0x498, 50), items=(0x560, 20), keyitems=(0x5B0, 20),
                        balls=(0x600, 16), tms=(0x640, 64), berries=(0x740, 46))
        if g == FRLG:
            return dict(party_cnt=0x34, party=0x38, money=0x290, coins=0x294,
                        pc_items=(0x298, 30), items=(0x310, 42), keyitems=(0x3B8, 30),
                        balls=(0x430, 13), tms=(0x464, 58), berries=(0x54C, 43))
        return dict(party_cnt=0x234, party=0x238, money=0x490, coins=0x494,
                    pc_items=(0x498, 50), items=(0x560, 30), keyitems=(0x5D8, 30),
                    balls=(0x650, 16), tms=(0x690, 64), berries=(0x790, 46))

    # --- trainer ---------------------------------------------------------------
    @property
    def trainer_name(self):
        return decode_text(self.data[self.sec(0): self.sec(0) + 7])

    @trainer_name.setter
    def trainer_name(self, s):
        o = self.sec(0)
        self.data[o:o + 8] = encode_text(s, 8)

    @property
    def trainer_gender(self):
        return self.data[self.sec(0) + 8]

    @property
    def trainer_id(self):
        o = self.sec(0)
        return struct.unpack_from("<HH", self.data, o + 0xA)

    @property
    def play_time(self):
        o = self.sec(0)
        h, m, s = struct.unpack_from("<HBB", self.data, o + 0xE)
        return h, m, s

    def _inv_base(self):
        # inventory/team block lives in section 1; items/money may be encrypted
        return self.sec(1)

    @property
    def money(self):
        o = self._inv_base() + self._layout()["money"]
        v, = struct.unpack_from("<I", self.data, o)
        return v ^ self.security_key if self.game != RS else v

    @money.setter
    def money(self, v):
        o = self._inv_base() + self._layout()["money"]
        v = max(0, min(self.money_max, v))
        struct.pack_into("<I", self.data, o, v ^ self.security_key if self.game != RS else v)
        if self.cfru == UNBOUND and v <= 999999:
            # Unbound keeps a 3-byte BCD copy of the money right before the u32
            digits = f"{v:06d}"
            for k in range(3):
                self.data[o - 3 + k] = (int(digits[2 * k + 1]) << 4) | int(digits[2 * k])

    @property
    def money_max(self):
        return 999_999_999 if self.cfru == UNBOUND else 999_999

    # --- party -----------------------------------------------------------------
    def party(self):
        L = self._layout()
        b = self._inv_base()
        n, = struct.unpack_from("<I", self.data, b + L["party_cnt"])
        n = min(n, 6)
        res = []
        cls = UnboundPartyMon if self.is_unbound else Pokemon
        for i in range(n):
            o = b + L["party"] + i * 100
            m = cls(self.data[o:o + 100])
            m.SHINY_THRESHOLD = self.shiny_threshold if self.is_unbound else 8
            res.append(m)
        return res

    def set_party_member(self, i, mon):
        L = self._layout()
        o = self._inv_base() + L["party"] + i * 100
        self.data[o:o + 100] = mon.to_bytes()

    # --- PC boxes --------------------------------------------------------------
    def _pc_buffer(self):
        """Concatenate section 5..13 data to a continuous PC buffer."""
        buf = bytearray()
        for sid in range(5, 14):
            o = self.sec(sid)
            buf += self.data[o:o + SECTION_DATA_SIZE[sid]]
        return buf

    def _pc_write_back(self, buf):
        p = 0
        for sid in range(5, 14):
            o = self.sec(sid)
            n = SECTION_DATA_SIZE[sid]
            self.data[o:o + n] = buf[p:p + n]
            p += n

    # Unbound: PC storage is a stream assembled from several regions (see UNBOUND_PC_REGIONS)
    def _unbound_regions(self):
        res = []
        for sid, start, end in UNBOUND_PC_REGIONS:
            base = self.sec(sid) if sid < SECTION_COUNT else sid * SECTION_SIZE
            res.append((base + start, end - start))
        return res

    def _unbound_gather(self):
        buf = bytearray()
        for off, length in self._unbound_regions():
            if off + length > len(self.data):
                raise ValueError("PC auxiliary storage is truncated")
            buf += self.data[off:off + length]
        return buf

    def _unbound_scatter(self, buf):
        p = 0
        for off, length in self._unbound_regions():
            self.data[off:off + length] = buf[p:p + length]
            p += length

    def box_pokemon(self):
        if self.is_unbound:
            buf = self._unbound_gather()
            res = {}
            for i in range(UNBOUND_BOXES * UNBOUND_BOX_SLOTS):
                mon = UnboundBoxMon(buf[i * UNBOUND_PC_RECORD:(i + 1) * UNBOUND_PC_RECORD])
                mon.SHINY_THRESHOLD = self.shiny_threshold
                if mon.valid:
                    res[(i // UNBOUND_BOX_SLOTS, i % UNBOUND_BOX_SLOTS)] = mon
            return res
        buf = self._pc_buffer()
        res = {}
        for box in range(14):
            for slot in range(30):
                off = 4 + (box * 30 + slot) * 80
                mon = Pokemon(buf[off:off + 80])
                if not mon.empty and mon.valid:
                    res[(box, slot)] = mon
        return res

    def set_box_pokemon(self, box, slot, mon):
        if self.is_unbound:
            buf = self._unbound_gather()
            i = box * UNBOUND_BOX_SLOTS + slot
            buf[i * UNBOUND_PC_RECORD:(i + 1) * UNBOUND_PC_RECORD] = _to_box_bytes(self, mon)
            self._unbound_scatter(buf)
            return
        buf = self._pc_buffer()
        off = 4 + (box * 30 + slot) * 80
        buf[off:off + 80] = mon.to_bytes()[:80]
        self._pc_write_back(buf)

    @property
    def BOXES(self):
        return UNBOUND_BOXES if self.is_unbound else 14

    BOX_SLOTS = 30

    def delete_box_pokemon(self, box, slot):
        if self.is_unbound:
            buf = self._unbound_gather()
            i = box * UNBOUND_BOX_SLOTS + slot
            buf[i * UNBOUND_PC_RECORD:(i + 1) * UNBOUND_PC_RECORD] = bytes(UNBOUND_PC_RECORD)
            self._unbound_scatter(buf)
            return
        buf = self._pc_buffer()
        off = 4 + (box * 30 + slot) * 80
        buf[off:off + 80] = bytes(80)
        self._pc_write_back(buf)

    # --- party size management ---------------------------------------------------
    @property
    def party_count(self):
        L = self._layout()
        return min(struct.unpack_from("<I", self.data, self._inv_base() + L["party_cnt"])[0], 6)

    @party_count.setter
    def party_count(self, n):
        L = self._layout()
        struct.pack_into("<I", self.data, self._inv_base() + L["party_cnt"], max(0, min(6, n)))

    # --- bag -------------------------------------------------------------------
    POCKETS = ["pc_items", "items", "keyitems", "balls", "tms", "berries"]

    def _unbound_pocket(self, pocket):
        """(absolute start offset, capacity in slots). Capacity = items now + the free (all
        zero) slots behind them, never beyond the pocket's hard end, so nothing else is
        overwritten."""
        sid, start, hard_end = UNBOUND_BAG[pocket]
        base = self.sec(sid) if sid < SECTION_COUNT else sid * SECTION_SIZE
        a = base + start
        slots = (hard_end - start) // 4
        n = 0
        while n < slots and struct.unpack_from("<H", self.data, a + n * 4)[0] != 0:
            n += 1
        cap = n
        while cap < slots and struct.unpack_from("<I", self.data, a + cap * 4)[0] == 0:
            cap += 1
        return a, cap

    qty_max = 999

    def pocket_capacity(self, pocket):
        if self.is_unbound and pocket in UNBOUND_BAG:
            return self._unbound_pocket(pocket)[1]
        return self._layout()[pocket][1]

    def bag(self, pocket):
        if self.is_unbound and pocket in UNBOUND_BAG:
            a, cap = self._unbound_pocket(pocket)
            items = []
            for i in range(cap):
                iid, qty = struct.unpack_from("<HH", self.data, a + i * 4)
                if iid == 0:
                    break
                items.append([iid, qty])
            return items
        L = self._layout()
        base, count = L[pocket]
        b = self._inv_base() + base
        key = self.security_key & 0xFFFF if self.game != RS else 0
        items = []
        for i in range(count):
            iid, qty = struct.unpack_from("<HH", self.data, b + i * 4)
            qty ^= key
            if iid != 0:
                items.append([iid, qty & 0xFFFF])
        return items

    def set_bag(self, pocket, items):
        if self.is_unbound and pocket in UNBOUND_BAG:
            a, cap = self._unbound_pocket(pocket)
            for i in range(cap):
                iid, qty = items[i] if i < len(items) else (0, 0)
                struct.pack_into("<HH", self.data, a + i * 4, iid, min(qty, 0xFFFF) if iid else 0)
            return
        L = self._layout()
        base, count = L[pocket]
        b = self._inv_base() + base
        key = self.security_key & 0xFFFF if self.game != RS else 0
        for i in range(count):
            if i < len(items):
                iid, qty = items[i]
            else:
                iid, qty = 0, 0
            struct.pack_into("<HH", self.data, b + i * 4, iid, (qty ^ key) & 0xFFFF)

    # --- writing ---------------------------------------------------------------
    def fix_checksums(self):
        # only touch sections that were actually changed; sections with an unknown
        # checksum scheme cannot be repaired and are reported in self.unfixable
        self.unfixable = []
        for sid, off in self.sections.items():
            if self.nonstandard and self.data[off:off + 0xFF4] == self._orig[off:off + 0xFF4]:
                continue   # unknown format: leave untouched sections exactly as they were
            if self.is_unbound and sid in UNBOUND_OPAQUE:
                continue
            if sid in self.bad_sections and self.nonstandard:
                self.unfixable.append(sid)
                continue
            n = self.sect_size.get(sid, SECTION_DATA_SIZE[sid])
            cs = checksum(self.data[off:off + n])
            struct.pack_into("<H", self.data, off + 0xFF6, cs)

    def to_bytes(self):
        self.fix_checksums()
        # mirror active slot onto the other slot's data, so the game can't prefer stale data
        return bytes(self.data)


# ----------------------------------------------------------------------------
# pokeemerald-expansion based hacks (Emerald Imperium, Pokémon Heart & Soul)
# Same encrypted 80/100-byte Pokemon structure as vanilla, but wider bit fields:
# species 11 bit, item 10 bit, exp 21 bit, moves 11 bit, ball 6 bit, 12 character nicknames,
# hidden nature offset (byte 0x12 >> 3), ability slot in the ribbon word (bits 29-30) and a shiny
# modifier bit in the health word (0x1E bit 14).
# ----------------------------------------------------------------------------
class ExpansionMon(Pokemon):
    SHINY_THRESHOLD = 8
    HAS_BALL = True
    ABILITY_BY_PID = False
    ABILITY_SLOTS = 3

    @staticmethod
    def _w(block, off, mask, v):
        old = struct.unpack_from("<H", block, off)[0]
        struct.pack_into("<H", block, off, (old & ~mask & 0xFFFF) | (v & mask))

    @property
    def species(self):
        return struct.unpack_from("<H", self.blocks["G"], 0)[0] & 0x7FF

    @species.setter
    def species(self, v):
        self._w(self.blocks["G"], 0, 0x7FF, v)
        self.raw[0x13] = (self.raw[0x13] | 2) if v else (self.raw[0x13] & ~2 & 0xFF)

    @property
    def held_item(self):
        return struct.unpack_from("<H", self.blocks["G"], 2)[0] & 0x3FF

    @held_item.setter
    def held_item(self, v):
        self._w(self.blocks["G"], 2, 0x3FF, v)

    @property
    def exp(self):
        return struct.unpack_from("<I", self.blocks["G"], 4)[0] & 0x1FFFFF

    @exp.setter
    def exp(self, v):
        old = struct.unpack_from("<I", self.blocks["G"], 4)[0]
        struct.pack_into("<I", self.blocks["G"], 4, (old & ~0x1FFFFF & 0xFFFFFFFF) | (v & 0x1FFFFF))

    @property
    def moves(self):
        return [w & 0x7FF for w in struct.unpack_from("<4H", self.blocks["A"], 0)]

    def set_move(self, i, v):
        self._w(self.blocks["A"], i * 2, 0x7FF, v)

    @property
    def pp(self):
        return [b & 0x7F for b in self.blocks["A"][8:12]]

    @property
    def ball(self):
        return struct.unpack_from("<H", self.blocks["G"], 10)[0] & 0x3F

    @ball.setter
    def ball(self, v):
        self._w(self.blocks["G"], 10, 0x3F, v)

    # 12 character nickname: characters 11 and 12 live in the exp word and the ball word
    @property
    def nickname(self):
        c11 = (struct.unpack_from("<I", self.blocks["G"], 4)[0] >> 21) & 0xFF
        c12 = (struct.unpack_from("<H", self.blocks["G"], 10)[0] >> 6) & 0xFF
        raw = bytes(self.nickname_raw) + (b"" if c11 == 0 and c12 == 0 else bytes([c11, c12]))
        return decode_text(raw)

    @nickname.setter
    def nickname(self, s):
        raw = encode_text(s, 12)
        self.nickname_raw = raw[:10]
        c11, c12 = raw[10], raw[11]
        if c11 == TERM and c12 == TERM:
            c11 = c12 = 0
        old = struct.unpack_from("<I", self.blocks["G"], 4)[0]
        struct.pack_into("<I", self.blocks["G"], 4, (old & ~(0xFF << 21) & 0xFFFFFFFF) | (c11 << 21))
        self._w(self.blocks["G"], 10, 0xFF << 6, c12 << 6)

    @property
    def nature(self):
        return (self.pid % 25) ^ (self.raw[0x12] >> 3)

    @property
    def ability_slot(self):
        return min((struct.unpack_from("<I", self.blocks["M"], 8)[0] >> 29) & 3, 2)

    @property
    def is_shiny(self):
        natural = is_shiny_pid(self.pid, self.otid, self.SHINY_THRESHOLD)
        flip = (struct.unpack_from("<H", self.raw, 0x1E)[0] >> 14) & 1
        return natural != bool(flip)

    def set_identity(self, nature=None, ability_slot=None, shiny=None, ratio=None):
        """The expansion stores nature, ability slot and shininess independently of the PID."""
        if nature is not None and nature != self.nature:
            self.raw[0x12] = (self.raw[0x12] & 7) | (((self.pid % 25) ^ nature) << 3)
        if ability_slot is not None:
            w = struct.unpack_from("<I", self.blocks["M"], 8)[0]
            struct.pack_into("<I", self.blocks["M"], 8, (w & ~(3 << 29) & 0xFFFFFFFF) | ((ability_slot & 3) << 29))
        if shiny is not None:
            natural = is_shiny_pid(self.pid, self.otid, self.SHINY_THRESHOLD)
            hw = struct.unpack_from("<H", self.raw, 0x1E)[0]
            hw = (hw | 0x4000) if natural != bool(shiny) else (hw & ~0x4000 & 0xFFFF)
            struct.pack_into("<H", self.raw, 0x1E, hw)


def expansion_item_pocket_filter(name, rom):
    return None


class ExpansionSave(PartyOps):
    """Common code of the pokeemerald-expansion saves. Subclasses give the sector geometry."""
    NAME = ""
    N = 14                    # sectors per slot
    SLOTS = 1
    SECTOR_DATA = 3968        # SaveBlock1 bytes per sector
    CHUNK = []                # bytes of each sector id that the checksum covers (and storage uses)
    STORAGE_FIRST = 5
    PARTY_CNT, PARTY, MONEY = 0x234, 0x238, 0x490
    KEY_OFF = 0xAC            # security key inside sector 0
    MONEY_KEY32 = True
    BOXES, BOX_SLOTS = 14, 30
    SIGNATURE = 0x08012025
    SHINY = 8
    POCKET_SPECS = {}         # key -> (SaveBlock1 offset, slots)
    POCKET_LABELS = {}
    POCKETS = []
    qty_max = 999
    is_unbound = False
    cfru = None
    game = EMERALD
    nonstandard = True
    shiny_threshold = 8

    # -- detection / loading -------------------------------------------------------------
    @classmethod
    def _read_slots(cls, data):
        best = None
        for slot in range(cls.SLOTS):
            ids, ok = {}, True
            for i in range(cls.N):
                o = (slot * cls.N + i) * SECTION_SIZE
                if o + SECTION_SIZE > len(data):
                    return None
                sid, = struct.unpack_from("<H", data, o + 0xFF4)
                sig, = struct.unpack_from("<I", data, o + 0xFF8)
                if sid >= cls.N or sid in ids or sig != cls.SIGNATURE:
                    ok = False
                    break
                ids[sid] = o
            if ok:
                cnt, = struct.unpack_from("<I", data, ids[0] + 0xFFC)
                if best is None or cnt > best[0]:
                    best = (cnt, ids, slot * cls.N * SECTION_SIZE)
        return best

    @classmethod
    def detect(cls, data):
        raise NotImplementedError

    def __init__(self, data, game=None):
        self.data = bytearray(data)
        self._orig = bytes(data)
        best = self._read_slots(self.data)
        if best is None:
            raise ValueError(f"Not a valid {self.NAME} save")
        self.counter, self.sections, self.slot_offset = best
        self.signature = self.SIGNATURE
        self.hack = self.NAME
        self.unfixable, self.bad_sections, self.detect_scores = [], [], {}
        self.sect_size = {sid: self.CHUNK[sid] for sid in self.sections}
        for sid, off in self.sections.items():
            stored, = struct.unpack_from("<H", self.data, off + 0xFF6)
            if checksum(self.data[off:off + self.CHUNK[sid]]) != stored:
                self.bad_sections.append(sid)
        self._storage = bytearray()
        for sid in range(self.STORAGE_FIRST, self.N):
            o = self.sections[sid]
            self._storage += self.data[o:o + self.CHUNK[sid]]

    def sec(self, sid):
        return self.sections[sid]

    legacy = False
    BOXES_N = 14

    def _party_off(self):
        return self._sb1(self.PARTY)

    def pocket_qty_max(self, pocket):
        return 1 if pocket == "keyitems" else 999

    # -- SaveBlock1 addressing -----------------------------------------------------------------
    def _sb1(self, off):
        return self.sections[1 + off // self.SECTOR_DATA] + off % self.SECTOR_DATA

    def _regions(self, off, slots):
        res = []
        while slots > 0:
            inside = off % self.SECTOR_DATA
            fit = min(slots, (self.SECTOR_DATA - inside) // 4)
            res.append((self._sb1(off), fit))
            off += fit * 4
            slots -= fit
        return res

    # -- trainer ---------------------------------------------------------------------------------
    @property
    def trainer_name(self):
        return decode_text(self.data[self.sec(0): self.sec(0) + 7])

    @trainer_name.setter
    def trainer_name(self, s):
        o = self.sec(0)
        self.data[o:o + 8] = encode_text(s, 8)

    @property
    def trainer_gender(self):
        return self.data[self.sec(0) + 8]

    @property
    def trainer_id(self):
        return struct.unpack_from("<HH", self.data, self.sec(0) + 0xA)

    @property
    def play_time(self):
        return struct.unpack_from("<HBB", self.data, self.sec(0) + 0xE)

    @property
    def security_key(self):
        return struct.unpack_from("<I", self.data, self.sec(0) + self.KEY_OFF)[0]

    @property
    def money(self):
        return struct.unpack_from("<I", self.data, self._sb1(self.MONEY))[0] ^ self.security_key

    @money.setter
    def money(self, v):
        v = max(0, min(self.money_max, v))
        struct.pack_into("<I", self.data, self._sb1(self.MONEY), v ^ self.security_key)

    money_max = 999_999

    # -- party ---------------------------------------------------------------------------------
    def _mon(self, raw):
        m = ExpansionMon(raw)
        m.SHINY_THRESHOLD = self.SHINY
        return m

    @property
    def party_count(self):
        return min(self.data[self._sb1(self.PARTY_CNT)], 6)

    @party_count.setter
    def party_count(self, n):
        self.data[self._sb1(self.PARTY_CNT)] = max(0, min(6, n))

    def party(self):
        o = self._sb1(self.PARTY)
        return [self._mon(self.data[o + i * 100:o + i * 100 + 100]) for i in range(self.party_count)]

    def set_party_member(self, i, mon):
        o = self._sb1(self.PARTY) + i * 100
        self.data[o:o + 100] = mon.to_bytes()

    # -- PC ----------------------------------------------------------------------------------------
    def _box_off(self, box, slot):
        return 4 + (box * self.BOX_SLOTS + slot) * 80

    @property
    def trainer_id_u32(self):
        a, b = self.trainer_id
        return a | (b << 16)

    def box_pokemon(self):
        res = {}
        for b in range(self.BOXES):
            for s in range(self.BOX_SLOTS):
                o = self._box_off(b, s)
                raw = self._storage[o:o + 80]
                if raw[0x13] & 2:
                    m = self._mon(raw)
                    if m.valid and m.species:
                        res[(b, s)] = m
        return res

    def set_box_pokemon(self, box, slot, mon):
        o = self._box_off(box, slot)
        self._storage[o:o + 80] = mon.to_bytes()[:80]

    def delete_box_pokemon(self, box, slot):
        o = self._box_off(box, slot)
        self._storage[o:o + 80] = bytes(80)

    # -- bag ------------------------------------------------------------------------------------------
    def pocket_capacity(self, pocket):
        return self.POCKET_SPECS[pocket][1]

    def bag(self, pocket):
        off, slots = self.POCKET_SPECS[pocket]
        key = self.security_key & 0xFFFF
        items = []
        for a, n in self._regions(off, slots):
            for i in range(n):
                iid, qty = struct.unpack_from("<HH", self.data, a + i * 4)
                if iid:
                    items.append([iid, (qty ^ key) & 0xFFFF])
        return items

    def set_bag(self, pocket, items):
        off, slots = self.POCKET_SPECS[pocket]
        key = self.security_key & 0xFFFF
        k = 0
        for a, n in self._regions(off, slots):
            for i in range(n):
                iid, qty = items[k] if k < len(items) else (0, 0)
                struct.pack_into("<HH", self.data, a + i * 4, iid, (min(qty, 0xFFFF) ^ key) & 0xFFFF)
                k += 1

    def item_filter(self, pocket):
        """Hack-specific knowledge about which item ids belong into a pocket (None = unknown)."""
        return None

    # -- writing ---------------------------------------------------------------------------------------
    def fix_checksums(self):
        p = 0
        for sid in range(self.STORAGE_FIRST, self.N):
            o, n = self.sections[sid], self.CHUNK[sid]
            self.data[o:o + n] = self._storage[p:p + n]
            p += n
        for sid, off in self.sections.items():
            struct.pack_into("<H", self.data, off + 0xFF6, checksum(self.data[off:off + self.CHUNK[sid]]))

    def to_bytes(self):
        self.fix_checksums()
        return bytes(self.data)


class ImperiumSave(ExpansionSave):
    NAME = "Emerald Imperium"
    N, SLOTS, SECTOR_DATA = 28, 1, 4084
    CHUNK = [2572, 4084, 4084, 4084, 2152] + [0] * 12 + [4084] * 8 + [1472, 0, 0]
    STORAGE_FIRST = 17
    PARTY_CNT, PARTY, MONEY, KEY_OFF = 0x234, 0x238, 0x490, 0x44
    SHINY = 36
    shiny_threshold = 36
    POCKET_SPECS = {"items": (0x560, 180), "megastones": (0x830, 76), "keyitems": (0x960, 60),
                    "balls": (0xA50, 50), "tms": (0xB18, 252), "berries": (0xF08, 70)}
    POCKETS = ["items", "megastones", "keyitems", "balls", "tms", "berries"]
    POCKET_LABELS = {"megastones": "Mega Stones"}
    V2_CHECKSUMS = [2940, 4084, 4084, 4084, 772] + [0] * 9 + [4084] * 12 + [1512, 0]

    @classmethod
    def detect(cls, data):
        # one slot of 28 sectors; no version field -> recognised by the checksum lengths
        if len(data) < cls.N * SECTION_SIZE:
            return False
        best = cls._read_slots(data)
        if best is None:
            return False
        return all(checksum(data[o:o + cls.CHUNK[sid]]) == struct.unpack_from("<H", data, o + 0xFF6)[0]
                   for sid, o in best[1].items())


class HeartAndSoulSave(ExpansionSave):
    NAME = "Pokémon Heart & Soul"
    N, SLOTS, SECTOR_DATA = 14, 2, 3968
    CHUNK = [3892, 3968, 3968, 3968, 3856] + [3968] * 8 + [2400]
    STORAGE_FIRST = 5
    PARTY_CNT, PARTY, MONEY, KEY_OFF = 0x238, 0x23C, 0x494, 0xAC
    MAGIC_OFF, MAGIC, SUPPORTED_VERSION = 0x10E0, 0xE8F828BC, 5
    SHINY = 8
    POCKET_SPECS = {"items": (0x564, 236), "medicine": (0xE28, 92), "balls": (0xA04, 39),
                    "tms": (0xAA0, 160), "berries": (0xD20, 66), "keyitems": (0x914, 60)}
    POCKETS = ["items", "medicine", "balls", "tms", "berries", "keyitems"]
    POCKET_LABELS = {"medicine": "Medicine / battle items"}
    # first hack item index of every run of items sharing a pocket (Heart & Soul combines pockets)
    POCKET_RUNS = [(1, "balls"), (28, "medicine"), (73, "items"), (102, "medicine"), (112, "items"),
                   (121, "medicine"), (133, "items"), (165, "keyitems"), (170, "items"), (461, "keyitems"),
                   (462, "items"), (514, "berries"), (582, "tms"), (690, "keyitems"), (758, "items"),
                   (770, "keyitems"), (773, "items"), (813, "keyitems"), (814, "items"), (816, "medicine"),
                   (820, "items"), (828, "balls"), (829, "items"), (874, "keyitems"), (875, "balls"),
                   (876, "items"), (878, "keyitems"), (897, "berries"), (898, "items"), (900, "keyitems")]

    @classmethod
    def pocket_of_item(cls, idx):
        pk = None
        for first, name in cls.POCKET_RUNS:
            if first <= idx:
                pk = name
        return pk

    def item_filter(self, pocket):
        return lambda iid: iid > 0 and self.pocket_of_item(iid) == pocket

    @classmethod
    def detect(cls, data):
        best = cls._read_slots(data)
        if best is None:
            return False
        sec1 = best[1][1 + cls.MAGIC_OFF // cls.SECTOR_DATA]
        off = sec1 + cls.MAGIC_OFF % cls.SECTOR_DATA
        return struct.unpack_from("<I", data, off)[0] == cls.MAGIC

    @property
    def save_version(self):
        return struct.unpack_from("<H", self.data, self._sb1(0))[0]


# ----------------------------------------------------------------------------
# Creating / converting Pokemon records
# ----------------------------------------------------------------------------
def unbound_compact(party):
    """100 byte CFRU party record -> 58 byte PC record (same fields, 10-bit moves)."""
    party = bytes(party)
    box = bytearray(58)
    box[0:0x1C] = party[0:0x1C]
    box[0x1C:0x27] = party[0x20:0x2B]
    moves = 0
    for i in range(4):
        moves |= (struct.unpack_from("<H", party, 0x2C + i * 2)[0] & 0x3FF) << (10 * i)
    box[0x27:0x2C] = moves.to_bytes(5, "little")
    box[0x2C:0x32] = party[0x38:0x3E]
    box[0x32:0x3A] = party[0x44:0x4C]
    return bytes(box)


def unbound_expand(box):
    """58 byte CFRU PC record -> 100 byte party-shaped record (no stats / level)."""
    box = bytes(box)
    party = bytearray(100)
    party[0:0x1C] = box[0:0x1C]
    party[0x20:0x2B] = box[0x1C:0x27]
    moves = int.from_bytes(box[0x27:0x2C], "little")
    for i in range(4):
        struct.pack_into("<H", party, 0x2C + i * 2, (moves >> (10 * i)) & 0x3FF)
    party[0x38:0x3E] = box[0x2C:0x32]
    party[0x44:0x4C] = box[0x32:0x3A]
    party[0x55] = 0xFF
    return bytes(party)


def make_new_mon(save, rom, species, level=5, nickname=None, rng=None):
    """Build a fresh, valid, party-shaped (100 byte) Pokemon of the right record type for `save`:
    trainer as OT, random PID / IVs, exp from the ROM growth rate, Tackle (id 33) as move,
    stats computed from the ROM base stats (or a flat 50 when the ROM has none)."""
    import random
    rng = rng or random
    tid, sid = save.trainer_id
    otid = tid | (sid << 16)
    pid = rng.getrandbits(32)
    info = rom.species_info(species) if rom else None
    base = info["base"] if info else [50] * 6
    growth = info["growth"] if info and info["growth"] < 6 else 0
    level = max(1, min(100, level))
    if nickname is None:
        nickname = (rom.species(species) if rom else f"#{species}")
    c = bytearray(100)                              # canonical decrypted layout (offsets as in CFRU)
    struct.pack_into("<II", c, 0, pid, otid)
    c[8:18] = encode_text(nickname, 10)
    c[18], c[19] = 2, 2                             # language English, "has species"
    c[20:27] = encode_text(save.trainer_name, 8)[:7]
    struct.pack_into("<H", c, 0x20, species)
    struct.pack_into("<I", c, 0x24, exp_for_level(growth, level))
    c[0x29] = 70                                    # friendship
    for i, mv in enumerate([33, 0, 0, 0]):
        struct.pack_into("<H", c, 0x2C + i * 2, mv)
        c[0x34 + i] = (rom.move_pp(mv) if rom and mv else 0) or (35 if mv else 0)
    ivs = [rng.randrange(32) for _ in range(6)]
    iv = 0
    for i, v in enumerate(ivs):
        iv |= v << (5 * i)
    struct.pack_into("<I", c, 0x48, iv)
    c[0x45] = 0                                     # met location
    gcode = {RS: 1, FRLG: 4, EMERALD: 3}.get(getattr(save, "game", EMERALD), 3)
    origins = level | (gcode << 7) | ((save.trainer_gender & 1) << 15)
    c[0x54] = level
    c[0x55] = 0xFF
    is_unbound = bool(getattr(save, "cfru", None))
    is_exp = isinstance(save, ExpansionSave)
    if is_unbound:
        c[0x2A] = 3                                 # Poke Ball in Unbound's ball order (Master, Ultra, Great, Poke)
        struct.pack_into("<H", c, 0x46, origins)
        mon = UnboundPartyMon(bytes(c))
        mon.SHINY_THRESHOLD = save.shiny_threshold
    else:
        cls = ExpansionMon if is_exp else Pokemon
        mon = cls(bytes(100))
        mon.pid = pid
        mon.otid = otid
        mon.raw[0:32] = c[0:32]
        mon.raw[80:100] = c[80:100]
        mon.nickname_raw = bytes(c[8:18])
        mon.ot_raw = bytes(c[20:27])
        if is_exp:
            mon.SHINY_THRESHOLD = save.SHINY
            struct.pack_into("<H", c, 0x2A, 1)      # ball word: Poke Ball is index 1 in the expansion order
        else:
            origins |= 4 << 11                      # ball (Poke Ball) lives in the origins word
        struct.pack_into("<H", c, 0x46, origins)
        for ch, a in (("G", 0x20), ("A", 0x2C), ("E", 0x38), ("M", 0x44)):
            mon.blocks[ch][:] = c[a:a + 12]
        if is_exp:
            mon.nickname = nickname
    mon.recalc_stats(base)
    return mon


def _to_box_bytes(save, mon):
    if getattr(save, "cfru", None):
        return unbound_compact(mon.to_bytes()) if mon.SIZE == 100 or mon.is_party else mon.to_bytes()[:58]
    return mon.to_bytes()[:80]


def load_save(data, game=None):
    """Open a save: returns SaveFile (vanilla, Unbound, Radical Red, Legacy), ImperiumSave or
    HeartAndSoulSave. `game` forces a layout; None auto-detects."""
    data = bytes(data)
    if game == "Imperium":
        return ImperiumSave(data)
    if game == "HeartAndSoul":
        return HeartAndSoulSave(data)
    if game is None:
        for cls in (ImperiumSave, HeartAndSoulSave):
            try:
                if cls.detect(data):
                    return cls(data)
            except Exception:
                pass
    return SaveFile(data, game=game)
