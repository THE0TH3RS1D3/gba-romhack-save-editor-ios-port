"""
Gen 3 Romhack Save Editor  (Pokemon GBA: Ruby/Sapphire/Emerald/FireRed/LeafGreen + hacks)

Run from source:   pip install PySide6-Essentials   ->   python romhack_save_editor.py
Build an .exe:     run build.bat (see README.md)

Workflow: open the ROM first (names for Pokemon / items / moves are read out of it),
then open the .sav. You can also drag & drop a .gba and a .sav onto the window.
All the format knowledge lives in gen3lib.py - this file is only the user interface.
"""
import base64
import json
import os
import random
import sys

from PySide6.QtCore import QMimeData, QPoint, Qt, QThread, QTimer, Signal
from PySide6.QtGui import QColor, QCursor, QDrag, QImage, QPainter, QPen, QPixmap
from PySide6.QtWidgets import (
    QAbstractItemView, QApplication, QCheckBox, QComboBox, QCompleter, QDialog, QDialogButtonBox,
    QFileDialog, QFormLayout, QGridLayout, QGroupBox, QHBoxLayout, QHeaderView, QLabel, QLineEdit,
    QMainWindow, QMenu, QMessageBox, QPlainTextEdit, QPushButton, QSizePolicy, QSpinBox, QTableWidget,
    QTableWidgetItem, QTabWidget, QToolTip, QVBoxLayout, QWidget,
)

import gen3lib as g3
from pkhex_assets import BOX_BG_B64

APP_TITLE = "Gen 3 Romhack Save Editor"
CACHE_DIR = os.path.join(os.path.expanduser("~"), ".gen3_romhack_editor", "cache")
GAME_CHOICES = [("Auto-detect", None), ("Pokémon Unbound", g3.UNBOUND), ("Pokémon Radical Red", g3.RADICAL_RED),
                ("Emerald Legacy", g3.EMERALD_LEGACY), ("Emerald Imperium", "Imperium"),
                ("Heart & Soul", "HeartAndSoul"), ("Ruby / Sapphire", g3.RS),
                ("FireRed / LeafGreen", g3.FRLG), ("Emerald", g3.EMERALD)]
SETTINGS_PATH = os.path.join(os.path.expanduser("~"), ".gen3_romhack_editor", "settings.json")
MIME_MON = "application/x-gen3-mon"       # drag & drop payload: "editor" or "slot:<box|party>:<index>"
DISP = [0, 1, 2, 4, 5, 3]                 # display order HP/Atk/Def/SpA/SpD/Spe -> index in save order
HP_TYPES = ["Fighting", "Flying", "Poison", "Ground", "Rock", "Bug", "Ghost", "Steel", "Fire", "Water",
            "Grass", "Electric", "Psychic", "Ice", "Dragon", "Dark"]
POCKET_LABELS = {"pc_items": "PC items", "items": "Items", "keyitems": "Key items", "balls": "Poké Balls",
                 "tms": "TMs / HMs", "berries": "Berries", "megastones": "Mega Stones",
                 "medicine": "Medicine / battle items"}


class RomWorker(QThread):
    """Scans a ROM in the background (a 32 MB ROM takes a few seconds the first time;
    results are cached per ROM hash, so re-opening is instant)."""
    done = Signal(object, str)

    def __init__(self, path):
        super().__init__()
        self.path = path

    def run(self):
        try:
            with open(self.path, "rb") as f:
                data = f.read()
            self.done.emit(g3.RomInfo(data, cache_dir=CACHE_DIR), "")
        except Exception as e:  # noqa: BLE001 - show any problem to the user
            self.done.emit(None, str(e))


class NameCombo(QComboBox):
    """Searchable id -> name selector (type part of a name or the number)."""

    def __init__(self, names_fn, count, ids=None):
        super().__init__()
        self.ids = ids
        self._names_fn = names_fn
        self.setEditable(True)
        self.setInsertPolicy(QComboBox.NoInsert)
        self.refill(names_fn, count)
        comp = self.completer()
        if comp is not None:
            comp.setFilterMode(Qt.MatchContains)
            comp.setCaseSensitivity(Qt.CaseInsensitive)
            comp.setCompletionMode(QCompleter.PopupCompletion)

    def refill(self, names_fn, count, ids=None):
        """ids: restrict the list to these item ids (e.g. the ones that belong into a bag pocket)."""
        if ids is not None:
            self.ids = ids
        self._names_fn = names_fn
        cur = self.get_id() if self.count() else None
        self.blockSignals(True)
        self.clear()
        for i in (self.ids if self.ids is not None else range(count)):
            self.addItem(f"{i:04d}  {names_fn(i)}", i)
        self.blockSignals(False)
        if cur is not None:
            self.set_id(cur)

    def set_id(self, i):
        idx = self.findData(i)
        if idx >= 0:
            self.setCurrentIndex(idx)
        elif self.ids is not None:   # exists, but is not an item of this category
            self.setEditText(f"{i:04d}  {self._names_fn(i)}  (not in this pocket)")
        else:  # id outside the known table: still show / keep it
            self.setEditText(f"{i:04d}  (unknown)")

    def get_id(self):
        txt = self.currentText().strip()
        try:
            return int(txt.split()[0])
        except (ValueError, IndexError):
            d = self.currentData()
            return d if d is not None else 0


def load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:  # noqa: BLE001 - missing / broken settings file = defaults
        return {}


def save_settings(d):
    try:
        os.makedirs(os.path.dirname(SETTINGS_PATH), exist_ok=True)
        with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
            json.dump(d, f, indent=1)
    except Exception:  # noqa: BLE001 - settings are a convenience only
        pass


def box_bg_pixmap():
    pm = QPixmap()
    if pm.loadFromData(base64.b64decode(BOX_BG_B64), "PNG") and not pm.isNull():
        return pm
    return None


class SettingsDialog(QDialog):
    """Sprite preview + interface mode. Both are off by default."""

    def __init__(self, parent, settings):
        super().__init__(parent)
        self.setWindowTitle("Settings")
        v = QVBoxLayout(self)
        self._pref = bool(settings.get("sprites"))
        self._forced = False
        self._busy = False
        self.sprites = QCheckBox("Sprite preview")
        self.sprites.setChecked(self._pref)
        n1 = QLabel("Small sprite (read from the ROM) next to the selected Pokémon. The first time it is "
                    "switched on the ROM is scanned for the sprite tables (a few seconds, then cached).")
        n1.setWordWrap(True)
        self._large_pref = bool(settings.get("large_sprite"))
        self.large = QCheckBox("Larger sprite in the classic interface")
        self.large.setChecked(self._large_pref)
        n1b = QLabel("Shows the sprite big, to the right of species / nickname / held item (those three "
                     "fields become a bit shorter). Needs the sprite preview; ignored in the PKHeX-style interface.")
        n1b.setWordWrap(True)
        self.pkhex = QCheckBox("PKHeX-style interface")
        self.pkhex.setChecked(bool(settings.get("pkhex")))
        n2 = QLabel("Tabbed Pokémon editor on the left, box grid / party / bag / save tabs on the right. "
                    "Drag the preview sprite into a box or party slot to place that Pokémon, drag slots "
                    "to move them, hover a Pokémon for a second for its summary, right-click or press Del "
                    "to delete. Needs sprites (switched on automatically while this mode is active).")
        n2.setWordWrap(True)
        for w in (self.sprites, n1, self.large, n1b, self.pkhex, n2):
            v.addWidget(w)
        self.pkhex.toggled.connect(self._sync)
        self.sprites.toggled.connect(self._sync)
        self._sync()
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)
        self.setMinimumWidth(440)

    def _sync(self, *_):
        if self._busy:
            return
        self._busy = True
        pk = self.pkhex.isChecked()
        if pk:
            if not self._forced:            # remember the user's own choice while the mode forces sprites on
                self._pref, self._forced = self.sprites.isChecked(), True
            self.sprites.setChecked(True)
            self.sprites.setEnabled(False)
        else:
            if self._forced:
                self._forced = False
                self.sprites.setEnabled(True)
                self.sprites.setChecked(self._pref)
            self._pref = self.sprites.isChecked()
        # the large sprite option only applies to the classic interface with sprites on
        can_large = (not pk) and self.sprites.isChecked()
        if self.large.isEnabled():
            self._large_pref = self.large.isChecked()
        self.large.setEnabled(can_large)
        self.large.setChecked(self._large_pref if can_large else False)
        self._busy = False

    def values(self):
        pk = self.pkhex.isChecked()
        return {"sprites": self._pref if pk else self.sprites.isChecked(), "pkhex": pk,
                "large_sprite": self.large.isChecked() if self.large.isEnabled() else self._large_pref}


class DragSprite(QLabel):
    """The preview sprite. Press and drag it into a slot of the box / party grid to place a
    copy of the Pokémon that is currently in the editor there."""

    def __init__(self, can_drag):
        super().__init__("")
        self.can_drag = can_drag
        self._press = None

    def mousePressEvent(self, e):
        if e.button() == Qt.LeftButton:
            self._press = e.position().toPoint()

    def mouseReleaseEvent(self, e):
        self._press = None

    def mouseMoveEvent(self, e):
        if self._press is None or not (e.buttons() & Qt.LeftButton):
            return
        if (e.position().toPoint() - self._press).manhattanLength() < QApplication.startDragDistance():
            return
        self._press = None
        if not self.can_drag():
            return
        drag = QDrag(self)
        md = QMimeData()
        md.setData(MIME_MON, b"editor")
        drag.setMimeData(md)
        pm = self.pixmap()
        if pm is not None and not pm.isNull():
            drag.setPixmap(pm)
            drag.setHotSpot(QPoint(pm.width() // 2, pm.height() // 2))
        drag.exec(Qt.CopyAction)


class SlotGrid(QWidget):
    """Box (6x5 on the PKHeX box background) or party (2x3) grid. Everything is painted by hand:
    click = select, drag a Pokémon = move / swap, drop the editor sprite = place, hover for a
    second = summary, Del / right-click = delete."""
    clicked = Signal(int)

    def __init__(self, win, kind, cols, rows, cell_w, cell_h, margin=0, bg=None):
        super().__init__()
        self.win, self.kind = win, kind
        self.cols, self.rows, self.cw, self.ch, self.m = cols, rows, cell_w, cell_h, margin
        self.bg = bg
        self.items = [None] * (cols * rows)
        self.selected = -1
        self.hover = -1
        self._press = None
        self.setFixedSize(cols * cell_w + 2 * margin, rows * cell_h + 2 * margin)
        self.setMouseTracking(True)
        self.setAcceptDrops(True)
        self.setFocusPolicy(Qt.StrongFocus)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.setInterval(1000)
        self._timer.timeout.connect(self._show_tip)

    def set_items(self, items, selected=-1):
        n = self.cols * self.rows
        self.items = (list(items) + [None] * n)[:n]
        self.selected = selected
        self.update()

    def index_at(self, pos):
        x, y = pos.x() - self.m, pos.y() - self.m
        if x < 0 or y < 0:
            return -1
        c, r = x // self.cw, y // self.ch
        if c >= self.cols or r >= self.rows:
            return -1
        return r * self.cols + c

    def cell_rect(self, i):
        r, c = divmod(i, self.cols)
        return self.m + c * self.cw, self.m + r * self.ch

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        if self.bg is not None:
            p.drawPixmap(self.rect(), self.bg)
        elif self.kind == "box":
            p.fillRect(self.rect(), QColor(150, 200, 90))
        else:
            p.fillRect(self.rect(), QColor(250, 250, 250))
        p.setPen(QPen(QColor(80, 70, 100, 210)))
        for c in range(1, self.cols):
            x = self.m + c * self.cw
            p.drawLine(x, self.m, x, self.m + self.rows * self.ch)
        for r in range(1, self.rows):
            y = self.m + r * self.ch
            p.drawLine(self.m, y, self.m + self.cols * self.cw, y)
        if self.m == 0:
            p.drawRect(0, 0, self.width() - 1, self.height() - 1)
        for i, mon in enumerate(self.items):
            x, y = self.cell_rect(i)
            if i == self.selected:
                p.fillRect(x + 1, y + 1, self.cw - 1, self.ch - 1, QColor(255, 255, 255, 100))
            elif i == self.hover:
                p.fillRect(x + 1, y + 1, self.cw - 1, self.ch - 1, QColor(255, 255, 255, 50))
            if mon is None:
                continue
            pm = self.win.slot_pixmap(mon, 64)
            if pm is not None:
                p.drawPixmap(x + (self.cw - pm.width()) // 2, y + (self.ch - pm.height()) // 2, pm)
            else:
                p.setPen(QPen(QColor(40, 40, 40)))
                p.drawText(x, y, self.cw, self.ch, Qt.AlignCenter | Qt.TextWordWrap, self.win.species_name(mon.species))
                p.setPen(QPen(QColor(80, 70, 100, 210)))
        p.end()

    # -- mouse -----------------------------------------------------------------------
    def mousePressEvent(self, e):
        if e.button() != Qt.LeftButton:
            return
        pos = e.position().toPoint()
        i = self.index_at(pos)
        self._press = (pos, i)
        self.setFocus()
        if i >= 0:
            self.clicked.emit(i)

    def mouseReleaseEvent(self, e):
        self._press = None

    def mouseMoveEvent(self, e):
        pos = e.position().toPoint()
        if self._press is not None and (e.buttons() & Qt.LeftButton):
            p0, i = self._press
            if (i >= 0 and self.items[i] is not None
                    and (pos - p0).manhattanLength() >= QApplication.startDragDistance()):
                self._press = None
                self._timer.stop()
                QToolTip.hideText()
                self._start_drag(i)
            return
        i = self.index_at(pos)
        if i != self.hover:
            self.hover = i
            self._timer.stop()
            QToolTip.hideText()
            if i >= 0 and self.items[i] is not None:
                self._timer.start()
            self.update()

    def leaveEvent(self, e):
        self.hover = -1
        self._timer.stop()
        QToolTip.hideText()
        self.update()

    def _show_tip(self):
        if 0 <= self.hover < len(self.items) and self.items[self.hover] is not None:
            QToolTip.showText(QCursor.pos(), self.win.mon_tooltip(self.items[self.hover]), self)

    def _start_drag(self, i):
        drag = QDrag(self)
        md = QMimeData()
        md.setData(MIME_MON, f"slot:{self.kind}:{i}".encode())
        drag.setMimeData(md)
        pm = self.win.slot_pixmap(self.items[i], 48)
        if pm is not None:
            drag.setPixmap(pm)
            drag.setHotSpot(QPoint(pm.width() // 2, pm.height() // 2))
        drag.exec(Qt.MoveAction)

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Delete:
            self.win.delete_selected()
        else:
            super().keyPressEvent(e)

    def contextMenuEvent(self, e):
        i = self.index_at(e.pos())
        if i < 0:
            return
        self.clicked.emit(i)
        if self.items[i] is None:
            return
        menu = QMenu(self)
        act = menu.addAction("Delete Pokémon")
        if menu.exec(e.globalPos()) == act:
            self.win.delete_mon()

    # -- drop ------------------------------------------------------------------------
    def dragEnterEvent(self, e):
        if e.mimeData().hasFormat(MIME_MON):
            e.acceptProposedAction()

    def dragMoveEvent(self, e):
        if e.mimeData().hasFormat(MIME_MON):
            e.acceptProposedAction()

    def dropEvent(self, e):
        md = e.mimeData()
        if not md.hasFormat(MIME_MON):
            return
        i = self.index_at(e.position().toPoint())
        if i < 0:
            return
        e.acceptProposedAction()
        self.win.handle_drop(self.kind, i, bytes(md.data(MIME_MON)).decode("utf-8", "ignore"))


class PokemonEditor(QGroupBox):
    def __init__(self, win, pkhex=False):
        super().__init__("" if pkhex else "Pokémon")
        self.win = win
        self.pkhex = pkhex
        self.mon = None
        self.where = None
        self.info = QLabel("")
        self.species = NameCombo(win.species_name, win.species_count())
        self.item = NameCombo(win.item_name, win.item_count())
        self.nick = QLineEdit()
        self.nick.setMaxLength(12)
        self.level = QSpinBox()
        self.level.setRange(1, 100)
        self.level.setToolTip("Level and Exp are linked through the species' growth rate (read from the ROM). "
                              "Gen 3 stores only the Exp of PC Pokémon; their level is derived from it. "
                              "For party Pokémon tick 'Recalculate party stats' below so the displayed stats "
                              "match (otherwise they refresh on the next level up).")
        self.exp = QSpinBox()
        self.exp.setRange(0, 2_000_000_000)
        self._sync = False
        self.level.valueChanged.connect(self.on_level_changed)
        self.exp.valueChanged.connect(self.on_exp_changed)
        self.species.currentIndexChanged.connect(self.on_species_changed)
        self.moves = [NameCombo(win.move_name, win.move_count()) for _ in range(4)]
        self.ivs = [QSpinBox() for _ in range(6)]
        self.evs = [QSpinBox() for _ in range(6)]
        for s in self.ivs:
            s.setRange(0, 31)
            s.valueChanged.connect(self.update_preview)
        for s in self.evs:
            s.setRange(0, 255)
            s.valueChanged.connect(self.update_preview)
        self.nature = QComboBox()
        for i, n in enumerate(g3.NATURES):
            up, down = g3.nature_effect(i)
            tag = "neutral" if up == down else f"+{g3.STAT_NAMES[up]} / -{g3.STAT_NAMES[down]}"
            self.nature.addItem(f"{n} ({tag})", i)
        self.ability = QComboBox()
        self.shiny = QCheckBox("Shiny")
        self.happy = QSpinBox()
        self.happy.setRange(0, 255)
        self.ball = QSpinBox()
        self.ball.setRange(0, 255)
        self.ball.setToolTip("Ball id as stored in the save (Unbound only)")
        self.recalc = QCheckBox("Recalculate party stats (needs ROM base stats)")
        self.recalc.setChecked(True)
        self.preview = QLabel("")
        # optional small sprite (off by default in the classic UI; always on in the PKHeX-style UI,
        # where it can be dragged into a box / party slot)
        self.sprites_on = False
        self.sprite = DragSprite(lambda: self.win.save is not None)
        self.large = (not pkhex) and bool(win.settings.get("sprites")) and bool(win.settings.get("large_sprite"))
        self.sprite_px = 56 if pkhex else (104 if self.large else 48)
        if pkhex:       # framed box around the sprite (room for a 2 px border)
            self.sprite.setFixedSize(self.sprite_px + 8, self.sprite_px + 8)
            self.sprite.setAlignment(Qt.AlignCenter)
            self.sprite.setStyleSheet("QLabel { border: 2px solid #8a8aa0; border-radius: 6px; "
                                      "background: rgba(128, 128, 128, 40); }")
        else:
            self.sprite.setFixedSize(self.sprite_px, self.sprite_px)
            self.sprite.setAlignment(Qt.AlignCenter)
        self.sprite.setVisible(pkhex)
        self._sprite_bytes = b""
        self.shiny.stateChanged.connect(self.refresh_sprite)
        self.apply_btn = QPushButton("Apply to save")
        self.apply_btn.clicked.connect(self.apply)
        if pkhex:
            self._layout_pkhex()
        else:
            self._layout_classic()
        self.setEnabled(False)

    def _layout_classic(self):
        f = QFormLayout(self)
        lab = self._label if self.large else (lambda t: t)
        if self.large:
            # big sprite to the right of species / nickname / held item (those fields get shorter);
            # fixed label widths keep both forms aligned
            f.addRow(self.info)
            sub = QFormLayout()
            for text, w in (("Species", self.species), ("Nickname", self.nick), ("Held item", self.item)):
                sub.addRow(lab(text), w)
            hb = QHBoxLayout()
            hb.addLayout(sub, 1)
            hb.addWidget(self.sprite, 0, Qt.AlignTop)
            f.addRow(hb)
        else:
            top = QHBoxLayout()
            top.addWidget(self.sprite)
            top.addWidget(self.info, 1)
            f.addRow(top)
            f.addRow("Species", self.species)
            f.addRow("Nickname", self.nick)
            f.addRow("Held item", self.item)
        f.addRow(lab("Level"), self.level)
        f.addRow(lab("Exp"), self.exp)
        for i, m in enumerate(self.moves):
            f.addRow(lab(f"Move {i + 1}"), m)
        row = QHBoxLayout()
        for n, s in zip(g3.STAT_NAMES, self.ivs):
            row.addWidget(QLabel(n))
            row.addWidget(s)
        f.addRow(lab("IVs"), row)
        row = QHBoxLayout()
        for n, s in zip(g3.STAT_NAMES, self.evs):
            row.addWidget(QLabel(n))
            row.addWidget(s)
        f.addRow(lab("EVs"), row)
        f.addRow(lab("Nature"), self.nature)
        f.addRow(lab("Ability"), self.ability)
        f.addRow(lab(""), self.shiny)
        f.addRow(lab("Happiness"), self.happy)
        f.addRow(lab("Ball"), self.ball)
        f.addRow(self.recalc)
        f.addRow(self.preview)
        f.addRow(self.apply_btn)

    def _label(self, text):
        lb = QLabel(text)
        lb.setMinimumWidth(84)
        return lb

    def _layout_pkhex(self):
        """Tabs like PKHeX: Main / Met / Stats / Attacks / OT-Misc, preview sprite in the tab bar corner."""
        self.setFlat(True)
        self.setStyleSheet("QGroupBox { border: 0; margin: 0; padding: 0; }")
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        self.tabs = QTabWidget()
        self.sprite.setToolTip("Drag this sprite into a box or party slot to place this Pokémon there.")
        self.shiny.setText("★ Shiny")
        self.pid_edit = QLineEdit()
        self.pid_edit.setReadOnly(True)
        # Main
        w = QWidget()
        f = QFormLayout(w)
        f.addRow("PID", self.pid_edit)
        f.addRow("Species", self.species)
        f.addRow("Nickname", self.nick)
        lr = QHBoxLayout()
        lr.addWidget(QLabel("Exp"))
        lr.addWidget(self.exp, 1)
        lr.addWidget(QLabel("Level"))
        lr.addWidget(self.level)
        f.addRow(lr)
        f.addRow("Nature", self.nature)
        f.addRow("Held item", self.item)
        f.addRow("Ability", self.ability)
        f.addRow("Friendship", self.happy)
        f.addRow("", self.shiny)
        self.tabs.addTab(w, "Main")
        # Met
        w = QWidget()
        f = QFormLayout(w)
        f.addRow("Ball", self.ball)
        note = QLabel("Origin game, met location and met level are not edited by this tool.")
        note.setWordWrap(True)
        f.addRow(note)
        self.tabs.addTab(w, "Met")
        # Stats
        w = QWidget()
        g = QGridLayout(w)
        for c, t in enumerate(["", "Base", "IVs", "EVs", "Stats"]):
            g.addWidget(QLabel(t), 0, c, Qt.AlignHCenter)
        self.base_lbl = [QLabel("-") for _ in range(6)]
        self.stat_lbl = [QLabel("-") for _ in range(6)]
        for r, si in enumerate(DISP):
            g.addWidget(QLabel(g3.STAT_NAMES[si] + ":"), r + 1, 0)
            g.addWidget(self.base_lbl[si], r + 1, 1, Qt.AlignHCenter)
            self.ivs[si].setMinimumWidth(84)      # wide enough for 2-3 digits next to the arrows
            self.evs[si].setMinimumWidth(84)
            g.addWidget(self.ivs[si], r + 1, 2)
            g.addWidget(self.evs[si], r + 1, 3)
            g.addWidget(self.stat_lbl[si], r + 1, 4, Qt.AlignHCenter)
        self.base_tot, self.iv_tot, self.ev_tot = QLabel("-"), QLabel("0"), QLabel("0")
        g.addWidget(QLabel("Total:"), 7, 0)
        g.addWidget(self.base_tot, 7, 1, Qt.AlignHCenter)
        g.addWidget(self.iv_tot, 7, 2, Qt.AlignHCenter)
        g.addWidget(self.ev_tot, 7, 3, Qt.AlignHCenter)
        self.hp_lbl = QLabel("")
        g.addWidget(self.hp_lbl, 8, 0, 1, 5)
        rb = QPushButton("Randomize IVs")
        rb.clicked.connect(self.randomize_ivs)
        rb2 = QPushButton("Randomize EVs")
        rb2.clicked.connect(self.randomize_evs)
        g.addWidget(rb, 9, 0, 1, 2)
        g.addWidget(rb2, 9, 2, 1, 3)
        g.addWidget(self.recalc, 10, 0, 1, 5)
        g.addWidget(self.preview, 11, 0, 1, 5)
        g.setRowStretch(12, 1)
        self.tabs.addTab(w, "Stats")
        # Attacks
        w = QWidget()
        g = QGridLayout(w)
        g.addWidget(QLabel("Current moves"), 0, 0)
        g.addWidget(QLabel("PP"), 0, 1)
        self.pp_lbl = [QLabel("") for _ in range(4)]
        for i in range(4):
            g.addWidget(self.moves[i], i + 1, 0)
            g.addWidget(self.pp_lbl[i], i + 1, 1)
        g.setColumnStretch(0, 1)
        g.setRowStretch(5, 1)
        self.tabs.addTab(w, "Attacks")
        # OT / Misc
        w = QWidget()
        f = QFormLayout(w)
        self.ot_lbl, self.tid_lbl, self.sid_lbl = QLabel("-"), QLabel("-"), QLabel("-")
        f.addRow("OT", self.ot_lbl)
        f.addRow("TID", self.tid_lbl)
        f.addRow("SID", self.sid_lbl)
        self.tabs.addTab(w, "OT/Misc")
        head = QHBoxLayout()
        head.addWidget(self.info, 1)
        head.addWidget(self.sprite)
        lay.addLayout(head)
        lay.addWidget(self.tabs)
        self.apply_btn.setText("Apply to selected slot")
        lay.addWidget(self.apply_btn)

    def randomize_ivs(self):
        for s in self.ivs:
            s.setValue(random.randrange(32))

    def randomize_evs(self):
        left = 510
        order = list(range(6))
        random.shuffle(order)
        vals = [0] * 6
        for i in order:
            vals[i] = random.randint(0, min(255, left))
            left -= vals[i]
        for s, v in zip(self.evs, vals):
            s.setValue(v)

    def refill_names(self):
        self.species.refill(self.win.species_name, self.win.species_count())
        self.item.refill(self.win.item_name, self.win.item_count())
        for m in self.moves:
            m.refill(self.win.move_name, self.win.move_count())

    def load(self, mon, where):
        self.mon, self.where = mon, where
        self._sync = True          # filling the widgets must not trigger level/exp recalculation
        self.setEnabled(True)
        self.info.setText("" if mon.valid else "⚠ Checksum of this Pokémon is invalid (bad egg / other format)")
        self.species.set_id(mon.species)
        self.item.set_id(mon.held_item)
        self.nick.setText(mon.nickname)
        self.exp.setValue(mon.exp)
        self.level.setValue(mon.level if mon.is_party and mon.level else self.level_for(mon.species, mon.exp))
        self._sync = False
        for i, m in enumerate(self.moves):
            m.set_id(mon.moves[i])
        for s, v in zip(self.ivs, mon.ivs):
            s.setValue(v)
        for s, v in zip(self.evs, mon.evs):
            s.setValue(v)
        self.nature.setCurrentIndex(mon.nature)
        self.shiny.setChecked(mon.is_shiny)
        self.happy.setValue(mon.happiness)
        self.ball.setEnabled(mon.HAS_BALL)
        self.ball.setValue(mon.ball if mon.HAS_BALL else 0)
        self.recalc.setEnabled(mon.is_party)
        self.fill_abilities(mon.species, mon.ability_slot)
        self._sync = False
        self.update_preview()
        self.refresh_sprite()
        if self.pkhex:
            self.fill_extras(mon)

    def fill_extras(self, mon):
        """PID, PP and original-trainer info shown on the PKHeX-style tabs."""
        self.pid_edit.setText(f"{mon.pid:08X}")
        try:
            pps = list(mon.pp)
        except Exception:  # noqa: BLE001
            pps = [0] * 4
        for lbl, v, mv in zip(self.pp_lbl, pps, mon.moves):
            lbl.setText(str(v) if mv else "0")
        self.ot_lbl.setText(getattr(mon, "ot_name", "") or "-")
        otid = getattr(mon, "otid", None)
        self.tid_lbl.setText(str(otid & 0xFFFF) if otid is not None else "-")
        self.sid_lbl.setText(str(otid >> 16) if otid is not None else "-")

    def set_sprites(self, on):
        self.sprites_on = on
        self.refresh_sprite()

    def refresh_sprite(self, *_):
        """Small front sprite read from the ROM (shiny palette when 'Shiny' is ticked)."""
        on = self.sprites_on and self.mon is not None
        self.sprite.setVisible(on or self.pkhex)
        if not on:
            self.sprite.setPixmap(QPixmap())
            return
        rom = self.win.rom
        img = rom.sprite_rgba(self.species.get_id(), shiny=self.shiny.isChecked()) if rom else None
        if img is None:
            self.sprite.setPixmap(QPixmap())
            self.sprite.setText("no\nsprite" if rom else "no\nROM")
            return
        w, h, data = img
        self._sprite_bytes = data          # QImage does not copy the buffer
        qi = QImage(self._sprite_bytes, w, h, w * 4, QImage.Format_RGBA8888)
        self.sprite.setText("")
        self.sprite.setPixmap(QPixmap.fromImage(qi).scaled(self.sprite_px, self.sprite_px, Qt.KeepAspectRatio,
                                                          Qt.SmoothTransformation))

    def growth(self, sid=None):
        info = self.species_data(self.species.get_id() if sid is None else sid)
        return info["growth"] if info and info["growth"] < 6 else 0

    def level_for(self, sid, exp):
        return g3.level_from_exp(self.growth(sid), exp)

    def on_level_changed(self, *_):
        if self._sync or self.mon is None:
            return
        self._sync = True
        self.exp.setValue(g3.exp_for_level(self.growth(), self.level.value()))
        self._sync = False
        self.update_preview()

    def on_exp_changed(self, *_):
        if self._sync or self.mon is None:
            return
        self._sync = True
        self.level.setValue(self.level_for(self.species.get_id(), self.exp.value()))
        self._sync = False
        self.update_preview()

    def on_species_changed(self, *_):
        """A new species can have another growth rate: keep the level, recompute the exp."""
        if self._sync or self.mon is None:
            return
        self._sync = True
        self.exp.setValue(g3.exp_for_level(self.growth(), self.level.value()))
        self._sync = False
        self.fill_abilities(self.species.get_id(), self.ability.currentData() or 0)
        self.update_preview()
        self.refresh_sprite()

    def species_data(self, sid):
        return self.win.rom.species_info(sid) if self.win.rom else None

    def fill_abilities(self, sid, slot):
        info = self.species_data(sid)
        names = ["Ability 1", "Ability 2", "Hidden ability"]
        if info:
            ids = info["abilities"]
            names = [self.win.rom.ability(ids[0]), self.win.rom.ability(ids[1]) if ids[1] else
                     self.win.rom.ability(ids[0]) + " (no 2nd ability)",
                     self.win.rom.ability(ids[2]) if ids[2] else "(no hidden ability)"]
            names = [f"{n}" for n in names]
        self.ability.clear()
        n_slots = self.mon.ABILITY_SLOTS if self.mon is not None else 2
        for i in range(n_slots):
            self.ability.addItem(f"{i + 1 if i < 2 else 'H'}: {names[i]}", i)
        self.ability.setCurrentIndex(min(slot, n_slots - 1))

    def update_preview(self, *_):
        if self.mon is None:
            return
        tot = sum(s.value() for s in self.evs)
        txt = f"EV total {tot}/510" + ("  ⚠ over the legal limit (works in game, but not legit)" if tot > 510 else "")
        info = self.species_data(self.species.get_id())
        if info:
            ratio = info["gender"]
            gender = {0: "♂", 1: "♀", 2: "genderless", None: "?"}[g3.gender_of(self.mon.pid, ratio)]
            lvl = self.level.value()
            st = g3.calc_stats(info["base"], [s.value() for s in self.ivs], [s.value() for s in self.evs],
                               lvl, self.nature.currentIndex())
            txt += f"\nGender {gender} · Level {lvl} · Growth {g3.GROWTH_NAMES[info['growth']] if info['growth'] < 6 else '?'}"
            txt += "\nStats: " + ", ".join(f"{n} {v}" for n, v in zip(g3.STAT_NAMES, st))
        self.preview.setText(txt)
        if self.pkhex and hasattr(self, "base_lbl"):
            self.fill_stat_grid(info)

    def fill_stat_grid(self, info):
        ivs = [s.value() for s in self.ivs]
        st = None
        if info:
            st = g3.calc_stats(info["base"], ivs, [s.value() for s in self.evs], self.level.value(),
                               self.nature.currentIndex())
        for i in range(6):
            self.base_lbl[i].setText(str(info["base"][i]) if info else "-")
            self.stat_lbl[i].setText(str(st[i]) if st else "-")
        self.base_tot.setText(str(sum(info["base"])) if info else "-")
        self.iv_tot.setText(str(sum(ivs)))
        self.ev_tot.setText(str(sum(s.value() for s in self.evs)))
        t = sum((v & 1) << i for i, v in enumerate(ivs)) * 15 // 63
        pw = sum(((v >> 1) & 1) << i for i, v in enumerate(ivs)) * 40 // 63 + 30
        self.hp_lbl.setText(f"Hidden Power: {HP_TYPES[t]} {pw}")

    def write_into(self, m):
        """Copy every editor field into the Pokémon object m (does not store it in the save)."""
        m.species = self.species.get_id()
        m.held_item = self.item.get_id()
        m.nickname = self.nick.text()
        m.exp = self.exp.value()
        for i, c in enumerate(self.moves):
            m.set_move(i, c.get_id())
        if m.is_party:
            m.level = self.level.value()
        info = self.species_data(m.species)
        m.ivs = [s.value() for s in self.ivs]
        m.evs = [s.value() for s in self.evs]
        m.happiness = self.happy.value()
        if m.HAS_BALL:
            m.ball = self.ball.value()
        slot = self.ability.currentData()
        m.set_identity(nature=self.nature.currentData(), ability_slot=slot if slot is not None else m.ability_slot,
                       shiny=self.shiny.isChecked(), ratio=info["gender"] if info else None)
        if m.is_party and self.recalc.isChecked() and info:
            m.recalc_stats(info["base"])
        return m

    def apply(self):
        if self.pkhex:
            self.win.apply_pkhex()
            return
        if self.mon is None or self.where is None:
            return
        m = self.write_into(self.mon)
        kind, a, b = self.where
        if kind == "party":
            self.win.save.set_party_member(a, m)
        else:
            self.win.save.set_box_pokemon(a, b, m)
        self.win.refresh_lists()
        self.win.status.setText("Pokémon applied (not yet written to file).")


class Main(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle(APP_TITLE)
        self.resize(1150, 760)
        self.setAcceptDrops(True)
        self.rom = None
        self.save = None
        self.save_raw = None
        self.save_path = None
        self.worker = None
        self._save_notes = []
        self.settings = load_settings()
        self.pkhex = bool(self.settings.get("pkhex"))
        self.cur_where = None
        self.cur_box = 0
        self._box_cache = None
        self._pix_cache = {}
        # widgets (re)created by build_ui
        self.game_combo = self.status = self.warning = self.editor = None
        self.box_grid = self.party_grid = self.box_combo = None
        self.mon_table = self.box_filter = self.show_empty = None
        self.slot_label = self.create_btn = self.delete_btn = None
        self.build_ui("Open a ROM (for names) and a save file. Drag & drop works too.")

    # -- UI construction -----------------------------------------------------------------
    def build_ui(self, status_text=None):
        """(Re)builds the whole window content for the current interface mode and refills it."""
        old_game = self.game_combo.currentIndex() if self.game_combo is not None else 0
        if status_text is None:
            status_text = self.status.text()
        warn_text = self.warning.text() if self.warning is not None else ""
        root = QWidget()
        self.setCentralWidget(root)          # the previous central widget is deleted by Qt
        v = QVBoxLayout(root)
        top = QHBoxLayout()
        b1 = QPushButton("Open ROM…")
        b2 = QPushButton("Open Save…")
        b3 = QPushButton("Save")
        b4 = QPushButton("Save as…")
        b1.clicked.connect(self.open_rom_dialog)
        b2.clicked.connect(self.open_save_dialog)
        b3.clicked.connect(lambda: self.write_save(False))
        b4.clicked.connect(lambda: self.write_save(True))
        for b in (b1, b2, b3, b4):
            top.addWidget(b)
        top.addSpacing(20)
        top.addWidget(QLabel("Save layout:"))
        self.game_combo = QComboBox()
        for label, _ in GAME_CHOICES:
            self.game_combo.addItem(label)
        self.game_combo.setCurrentIndex(old_game)
        self.game_combo.setToolTip("Auto-detect tries all layouts and keeps the one that makes "
                                   "sense. Override it if a hack is detected wrongly.")
        self.game_combo.currentIndexChanged.connect(self.reload_save_layout)
        top.addWidget(self.game_combo)
        top.addStretch()
        sb = QPushButton("Settings…")
        sb.clicked.connect(self.open_settings)
        top.addWidget(sb)
        v.addLayout(top)
        self.status = QLabel(status_text)
        v.addWidget(self.status)
        self.warning = QLabel(warn_text)
        self.warning.setStyleSheet("color: #b45309;")
        self.warning.setWordWrap(True)
        v.addWidget(self.warning)
        self.mon_index = []
        self.box_grid = self.party_grid = self.box_combo = None
        self.mon_table = self.box_filter = self.show_empty = None
        self.slot_label = self.create_btn = self.delete_btn = None
        if self.pkhex:
            self.build_pkhex(v)
        else:
            self.build_classic(v)
        self.sync_sprites()
        self.repopulate()

    def build_classic(self, v):
        self.tabs = QTabWidget()
        v.addWidget(self.tabs)

        # --- Pokemon tab
        pk = QWidget()
        h = QHBoxLayout(pk)
        self.mon_table = QTableWidget(0, 4)
        self.mon_table.setHorizontalHeaderLabels(["Location", "Species", "Nickname", "Lv"])
        self.mon_table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.mon_table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.mon_table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.mon_table.itemSelectionChanged.connect(self.on_mon_selected)
        left = QVBoxLayout()
        flt = QHBoxLayout()
        self.box_filter = QComboBox()
        self.box_filter.currentIndexChanged.connect(self.refresh_lists)
        self.show_empty = QCheckBox("Show empty slots")
        self.show_empty.setChecked(True)
        self.show_empty.stateChanged.connect(self.refresh_lists)
        flt.addWidget(QLabel("Show:"))
        flt.addWidget(self.box_filter)
        flt.addWidget(self.show_empty)
        flt.addStretch()
        left.addLayout(flt)
        left.addWidget(self.mon_table)
        h.addLayout(left, 3)
        right = QVBoxLayout()
        self.slot_box = QGroupBox("Slot")
        sf = QFormLayout(self.slot_box)
        self.slot_label = QLabel("Select a slot")
        self.create_btn = QPushButton("Create new Pokémon here (then set species etc. on the right)")
        self.create_btn.clicked.connect(self.create_mon)
        self.delete_btn = QPushButton("Delete this Pokémon")
        self.delete_btn.clicked.connect(self.delete_mon)
        sf.addRow(self.slot_label)
        sf.addRow(self.create_btn)
        sf.addRow(self.delete_btn)
        self.create_btn.setEnabled(False)
        self.delete_btn.setEnabled(False)
        # maximized window: the small slot box keeps its natural height, the Pokémon editor gets the rest
        self.slot_box.setSizePolicy(QSizePolicy.Preferred, QSizePolicy.Maximum)
        right.addWidget(self.slot_box, 0)
        self.editor = PokemonEditor(self)
        right.addWidget(self.editor, 1)
        h.addLayout(right, 2)
        self.tabs.addTab(pk, "Pokémon")
        self.tabs.addTab(self.make_bag_widget(), "Bag")
        self.tabs.addTab(self.make_trainer_widget(), "Trainer")
        self.tabs.addTab(self.make_info_widget(), "ROM / Save info")

    def build_pkhex(self, v):
        """PKHeX-style layout: tabbed editor on the left, Box / Party / Bag / SAV on the right."""
        body = QHBoxLayout()
        v.addLayout(body, 1)
        self.editor = PokemonEditor(self, pkhex=True)
        self.editor.setFixedWidth(400)
        body.addWidget(self.editor, 0)
        self.rtabs = QTabWidget()
        body.addWidget(self.rtabs, 1)
        # Box
        bw = QWidget()
        bl = QVBoxLayout(bw)
        nav = QHBoxLayout()
        prev, nxt = QPushButton("<<"), QPushButton(">>")
        prev.clicked.connect(lambda: self.step_box(-1))
        nxt.clicked.connect(lambda: self.step_box(1))
        self.box_combo = QComboBox()
        self.box_combo.setMinimumWidth(160)
        self.box_combo.currentIndexChanged.connect(self.on_box_combo)
        nav.addStretch()
        nav.addWidget(prev)
        nav.addWidget(self.box_combo)
        nav.addWidget(nxt)
        nav.addStretch()
        bl.addLayout(nav)
        self.box_grid = SlotGrid(self, "box", 6, 5, 96, 80, margin=19, bg=box_bg_pixmap())
        self.box_grid.clicked.connect(lambda i: self.select_slot("box", i))
        bl.addWidget(self.box_grid, 0, Qt.AlignHCenter)
        bl.addStretch()
        self.rtabs.addTab(bw, "Box")
        # Party
        pw = QWidget()
        pl = QVBoxLayout(pw)
        self.party_grid = SlotGrid(self, "party", 2, 3, 104, 90)
        self.party_grid.clicked.connect(lambda i: self.select_slot("party", i))
        pl.addWidget(self.party_grid, 0, Qt.AlignLeft | Qt.AlignTop)
        pl.addStretch()
        self.rtabs.addTab(pw, "Party")
        self.rtabs.addTab(self.make_bag_widget(), "Bag")
        # SAV: trainer block + ROM / save overview only
        sav = QWidget()
        sl = QVBoxLayout(sav)
        tg = QGroupBox("Trainer Information")
        tl = QVBoxLayout(tg)
        tl.addWidget(self.make_trainer_widget())
        sl.addWidget(tg)
        ig = QGroupBox("ROM / Save info")
        il = QVBoxLayout(ig)
        il.addWidget(self.make_info_widget())
        sl.addWidget(ig, 1)
        self.rtabs.addTab(sav, "SAV")

    def make_bag_widget(self):
        bag = QWidget()
        bv = QVBoxLayout(bag)
        self.pocket_box = QComboBox()
        for k in g3.SaveFile.POCKETS:
            self.pocket_box.addItem(POCKET_LABELS.get(k, k), k)
        self.pocket_box.currentIndexChanged.connect(self.load_bag)
        bv.addWidget(self.pocket_box)
        self.bag_info = QLabel("")
        bv.addWidget(self.bag_info)
        self.bag_table = QTableWidget(0, 3)
        self.bag_table.setHorizontalHeaderLabels(["Item (type to search)", "Quantity", ""])
        self.bag_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        self.bag_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeToContents)
        self.bag_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeToContents)
        bv.addWidget(self.bag_table)
        bb = QHBoxLayout()
        add = QPushButton("Add row")
        add.clicked.connect(lambda: self.add_bag_row(1, 1))
        app = QPushButton("Apply pocket")
        app.clicked.connect(self.apply_bag)
        bb.addWidget(add)
        bb.addWidget(app)
        bb.addStretch()
        bv.addLayout(bb)
        return bag

    def make_trainer_widget(self):
        tr = QWidget()
        tf = QFormLayout(tr)
        self.t_name = QLineEdit()
        self.t_name.setMaxLength(7)
        self.t_money = QSpinBox()
        self.t_money.setRange(0, 999999)
        self.t_info = QLabel("")
        tf.addRow("Name", self.t_name)
        tf.addRow("Money", self.t_money)
        tf.addRow("Info", self.t_info)
        ap = QPushButton("Apply trainer")
        ap.clicked.connect(self.apply_trainer)
        tf.addRow(ap)
        return tr

    def make_info_widget(self):
        self.info_text = QPlainTextEdit()
        self.info_text.setReadOnly(True)
        return self.info_text

    def repopulate(self):
        """Fill the freshly built widgets from the loaded ROM / save."""
        if self.rom is not None:
            self.editor.refill_names()
        if self.save is not None:
            self.refill_box_filter()
            self.fill_pockets()
            self.fill_box_nav()
            self.fill_trainer()
            if self.pkhex:
                self.load_template()
            self.refresh_lists()
            self.load_bag()
        self.update_info()

    # -- settings --------------------------------------------------------------------------
    def open_settings(self):
        dlg = SettingsDialog(self, self.settings)
        if not dlg.exec():
            return
        new = dlg.values()
        mode_changed = new["pkhex"] != self.pkhex
        # the editor layout depends on the large-sprite option, so it has to be rebuilt when that changes
        layout_changed = (not new["pkhex"]) and (
            bool(new["sprites"] and new["large_sprite"]) != bool(self.settings.get("sprites") and self.settings.get("large_sprite")))
        self.settings.update(new)
        save_settings(self.settings)
        self.pkhex = new["pkhex"]
        self.cur_where = None
        if mode_changed or layout_changed:
            self.build_ui()
        else:
            self.sync_sprites()
        self.status.setText("PKHeX-style interface on." if self.pkhex and mode_changed else
                            "Settings applied.")

    def sprites_wanted(self):
        return self.pkhex or bool(self.settings.get("sprites"))

    def sync_sprites(self):
        """Applies the sprite setting: scans the ROM for sprite tables the first time (cached afterwards)."""
        on = self.sprites_wanted()
        self._pix_cache.clear()
        if on and self.rom is not None:
            if self.rom.gfx is None:
                self.status.setText("Scanning the ROM for sprite tables…")
                QApplication.processEvents()
            self.rom.ensure_gfx()
        if self.editor is not None:
            self.editor.set_sprites(on)
        if self.pkhex:
            self.refresh_grids(reparse=False)

    def slot_pixmap(self, mon, px):
        """Cached front sprite of a Pokémon (shiny palette for shiny ones), or None."""
        if self.rom is None:
            return None
        key = (mon.species, bool(mon.is_shiny), px)
        if key not in self._pix_cache:
            pm = None
            img = self.rom.sprite_rgba(mon.species, shiny=bool(mon.is_shiny))
            if img is not None:
                w, h, data = img
                qi = QImage(data, w, h, w * 4, QImage.Format_RGBA8888)
                pm = QPixmap.fromImage(qi)
                if px != w:
                    pm = pm.scaled(px, px, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self._pix_cache[key] = pm
        return self._pix_cache[key]

    def mon_tooltip(self, m):
        """Summary shown when hovering a Pokémon in the box / party grid."""
        lines = [self.species_name(m.species),
                 "IVs: " + " / ".join(f"{v} {n}" for n, v in zip(g3.STAT_NAMES, m.ivs))]
        info = self.rom.species_info(m.species) if self.rom else None
        if info:
            ids = info["abilities"]
            aid = ids[min(m.ability_slot, len(ids) - 1)] or ids[0]
            lines.append("Ability: " + self.rom.ability(aid))
        lines.append(f"Level: {m.level or self.mon_level(m) or '?'}")
        lines.append(f"{g3.NATURES[m.nature]} Nature" + ("   ★ Shiny" if m.is_shiny else ""))
        lines += [f"- {self.move_name(mv)}" for mv in m.moves if mv]
        return "\n".join(lines)

    # -- drag & drop -------------------------------------------------------------
    def dragEnterEvent(self, e):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()

    def dropEvent(self, e):
        paths = [u.toLocalFile() for u in e.mimeData().urls()]
        # ROM first so names are available when the save is shown
        for p in sorted(paths, key=lambda p: 0 if p.lower().endswith((".gba", ".bin")) else 1):
            if p.lower().endswith((".gba", ".bin")):
                self.open_rom(p)
            elif p.lower().endswith((".sav", ".srm")):
                self.open_save(p)

    # -- name helpers (fall back to numbers when no ROM / unknown id) -------------------
    def species_name(self, i):
        return self.rom.species(i) if self.rom else g3.fallback_species(i)

    def item_name(self, i):
        return self.rom.item(i) if self.rom else ("(none)" if i == 0 else g3.fallback_item(i))

    def move_name(self, i):
        return self.rom.move(i) if self.rom else g3.fallback_move(i)

    def species_count(self):
        return len(self.rom.species_names) if self.rom and self.rom.species_names else 1500

    def item_count(self):
        return len(self.rom.item_names) if self.rom and self.rom.item_names else 1000

    def move_count(self):
        return len(self.rom.move_names) if self.rom and self.rom.move_names else 1000

    # -- ROM ----------------------------------------------------------------------
    def open_rom_dialog(self):
        p, _ = QFileDialog.getOpenFileName(self, "Open ROM", "", "GBA ROM (*.gba *.bin);;All (*)")
        if p:
            self.open_rom(p)

    def open_rom(self, path):
        self.status.setText(f"Scanning ROM… ({os.path.basename(path)})")
        self.worker = RomWorker(path)
        self.worker.done.connect(self.on_rom_loaded)
        self.worker.start()

    def on_rom_loaded(self, rom, error):
        if rom is None:
            QMessageBox.critical(self, "Error", f"Could not read ROM:\n{error}")
            return
        self.rom = rom
        g3.UnboundMon.move_pp_lookup = rom.move_pp if rom.move_pps else None
        hack = f" [{rom.hack}]" if rom.hack else ""
        self.status.setText(f"ROM loaded: {rom.game_title} ({rom.game_code}){hack} - "
                            f"{len(rom.species_names)} species, {len(rom.item_names)} items, "
                            f"{len(rom.move_names)} moves")
        self.editor.refill_names()
        self.sync_sprites()
        self.refresh_lists()
        self.load_bag()
        self.check_match()
        self.update_info()

    # -- Save ---------------------------------------------------------------------
    def open_save_dialog(self):
        p, _ = QFileDialog.getOpenFileName(self, "Open Save", "", "Save (*.sav *.srm);;All (*)")
        if p:
            self.open_save(p)

    def selected_game(self):
        return GAME_CHOICES[self.game_combo.currentIndex()][1]

    def open_save(self, path):
        try:
            with open(path, "rb") as f:
                raw = f.read()
            save = g3.load_save(raw, game=self.selected_game())
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Error", str(e))
            return
        self.save, self.save_raw, self.save_path = save, raw, path
        self.on_save_loaded()

    def reload_save_layout(self, *_):
        """User changed the layout selector: re-parse the original bytes with that layout
        (unsaved edits are discarded)."""
        if self.save_raw is None:
            return
        try:
            self.save = g3.load_save(self.save_raw, game=self.selected_game())
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Error", str(e))
            return
        self.on_save_loaded()

    def on_save_loaded(self):
        s = self.save
        self.status.setText(f"Save loaded: {s.game} layout, slot @0x{s.slot_offset:X}, "
                            f"save counter {s.counter}")
        notes = []
        if s.hack:
            self.status.setText(self.status.text() + f"  [{s.hack} save]")
        if s.cfru == g3.RADICAL_RED:
            notes.append("ℹ Pokémon Radical Red save (CFRU layout, detected by its security-key pattern): "
                         "party, PC, bag and money are supported. Use the layout selector if it was "
                         "detected wrongly.")
        elif s.is_unbound:
            notes.append("ℹ Pokémon Unbound save: party, PC (24 boxes), bag pockets, key items and money "
                         "are supported (layout from the PUSE editor). Level of PC Pokémon is not shown; "
                         "battle points / section 4 are never touched.")
        elif isinstance(s, g3.ExpansionSave):
            notes.append(f"ℹ {s.hack} save (pokeemerald-expansion based): party, PC, bag and money are "
                         "supported. Species / move / item names come from the ROM when it can be read; "
                         "otherwise numbers are shown.")
        elif s.legacy:
            notes.append("ℹ Pokémon Emerald Legacy save: Emerald layout with the 120-slot item pocket.")
        elif s.nonstandard:
            notes.append("ℹ Non-standard save format (custom checksum section sizes). Only sections "
                         "you change are rewritten; party/PC/bag offsets are unverified for this hack.")
        if s.bad_sections:
            notes.append(f"⚠ Checksum scheme unknown for sections {sorted(s.bad_sections)}.")
        self._save_notes = notes
        self.check_match()
        self.cur_where = None
        self.cur_box = 0
        self.repopulate()

    def fill_trainer(self):
        s = self.save
        self.t_name.setText(s.trainer_name)
        self.t_money.setRange(0, s.money_max)
        self.t_money.setValue(s.money)
        tid, sid = s.trainer_id
        h, m, sec = s.play_time
        self.t_info.setText(f"TID {tid:05d} / SID {sid:05d}    Playtime {h}:{m:02d}:{sec:02d}")

    def check_match(self):
        """Warn when ROM and save obviously belong to different games (names would be wrong)."""
        notes = list(self._save_notes)
        if self.rom and self.save:
            rom_unb = "Unbound" in (self.rom.hack or "")
            sav_unb = self.save.hack == "Pokémon Unbound"
            if sav_unb and not rom_unb:
                notes.append("⚠ This save is from Pokémon Unbound but the opened ROM is not - "
                             "names will be wrong. Open the Unbound ROM.")
            elif rom_unb and not sav_unb:
                notes.append("⚠ The ROM is Pokémon Unbound but this save does not look like an "
                             "Unbound save.")
        self.warning.setText("\n".join(notes))

    def update_info(self):
        lines = []
        if self.rom:
            lines += [f"ROM: {self.rom.game_title} ({self.rom.game_code})"
                      + (f"   recognised as: {self.rom.hack}" if self.rom.hack else "")] + self.rom.notes + [""]
        if self.save:
            s = self.save
            lines += [f"Save: {s.game} layout   active slot @0x{s.slot_offset:X}   counter {s.counter}"
                      + (f"   recognised as: {s.hack}" if s.hack else ""),
                      f"Section signature: 0x{s.signature:08X}",
                      f"Layout scores: {s.detect_scores}",
                      f"Non-standard sections (checksum size): "
                      f"{ {k: v for k, v in s.sect_size.items() if k < 14 and v != g3.SECTION_DATA_SIZE[k]} }"]
        self.info_text.setPlainText("\n".join(lines))

    def write_save(self, as_new):
        if not self.save:
            return
        out = self.save.to_bytes()
        if self.save.unfixable:
            r = QMessageBox.warning(
                self, "Checksum cannot be repaired",
                f"Sections {self.save.unfixable} were changed but their checksum scheme is unknown. "
                "The game would probably reject this save. Write it anyway?",
                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if r != QMessageBox.Yes:
                return
        p = self.save_path
        if as_new or not p:
            p, _ = QFileDialog.getSaveFileName(self, "Save as", self.save_path or "", "Save (*.sav)")
            if not p:
                return
        elif os.path.exists(p):
            with open(p, "rb") as src, open(p + ".bak", "wb") as bak:
                bak.write(src.read())
        with open(p, "wb") as f:
            f.write(out)
        self.save_path = p
        self.save_raw = out
        self.status.setText(f"Written: {p}" + ("  (backup: .bak)" if not as_new else ""))

    # -- pokemon -----------------------------------------------------------------
    def refill_box_filter(self):
        if self.box_filter is None:
            return
        self.box_filter.blockSignals(True)
        self.box_filter.clear()
        self.box_filter.addItem("Party + all boxes", "all")
        self.box_filter.addItem("Party only", "party")
        if self.save:
            for b in range(self.save.BOXES):
                self.box_filter.addItem(f"Box {b + 1}", b)
        self.box_filter.blockSignals(False)

    def refresh_lists(self, *_):
        if self.pkhex:
            self.refresh_grids()
            return
        keep = self.cur_where
        self.mon_table.setRowCount(0)
        self.mon_index = []
        if not self.save:
            return
        flt = self.box_filter.currentData() if self.box_filter.count() else "all"
        show_empty = self.show_empty.isChecked()
        rows = []
        party = self.save.party()
        if flt in ("all", "party"):
            for i in range(6):
                if i < len(party):
                    rows.append((f"Party {i + 1}", party[i], ("party", i, 0)))
                elif show_empty and i == len(party):
                    rows.append((f"Party {i + 1}", None, ("party", i, 0)))
        if flt != "party":
            boxes = self.save.box_pokemon()
            boxes_to_show = range(self.save.BOXES) if flt == "all" else [flt]
            for b in boxes_to_show:
                for sl in range(self.save.BOX_SLOTS):
                    m = boxes.get((b, sl))
                    if m is not None or show_empty:
                        rows.append((f"Box {b + 1} / {sl + 1}", m, ("box", b, sl)))
        for label, m, where in rows:
            r = self.mon_table.rowCount()
            self.mon_table.insertRow(r)
            if m is None:
                sp, nick, lv = "(empty)", "", ""
            else:
                sp = f"{self.species_name(m.species)} ({m.species})" + ("" if m.valid else "  ⚠")
                nick, lv = m.nickname, str(m.level or self.mon_level(m) or "")
            self.mon_table.setItem(r, 0, QTableWidgetItem(label))
            self.mon_table.setItem(r, 1, QTableWidgetItem(sp))
            self.mon_table.setItem(r, 2, QTableWidgetItem(nick))
            self.mon_table.setItem(r, 3, QTableWidgetItem(lv))
            self.mon_index.append((m, where))
            if keep is not None and where == keep:
                self.mon_table._cur = r      # (test helper; real Qt reselects via selectRow below)
        self.reselect(keep)

    def mon_level(self, m):
        info = self.rom.species_info(m.species) if self.rom else None
        if info and info["growth"] < 6:
            return g3.level_from_exp(info["growth"], m.exp)
        return 0

    def reselect(self, where):
        if where is None:
            return
        for r, (_, w) in enumerate(self.mon_index):
            if w == where:
                self.mon_table.selectRow(r)
                return

    def on_mon_selected(self):
        r = self.mon_table.currentRow()
        if 0 <= r < len(self.mon_index):
            m, where = self.mon_index[r]
            self.cur_where = where
            kind, a, b = where
            label = f"Party {a + 1}" if kind == "party" else f"Box {a + 1} / slot {b + 1}"
            if m is None:
                self.slot_label.setText(f"{label}: empty")
                self.editor.setEnabled(False)
            else:
                self.slot_label.setText(f"{label}: {self.species_name(m.species)}")
                self.editor.load(m, where)
            self.create_btn.setEnabled(m is None)
            self.delete_btn.setEnabled(m is not None)

    def create_mon(self):
        if not self.save or self.cur_where is None:
            return
        kind, a, b = self.cur_where
        sp = 1      # placeholder species; it is changed in the editor right afterwards
        try:
            mon = g3.make_new_mon(self.save, self.rom, sp, 5)
            if kind == "party":
                self.save.add_party_member(mon)
            else:
                self.save.set_box_pokemon(a, b, mon)
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Error", str(e))
            return
        self.refresh_lists()
        self.status.setText("New Pokémon created (not yet written to file). Choose its species, level, "
                            "moves etc. on the right and press 'Apply to save'.")
        self.on_mon_selected()

    def delete_mon(self):
        if not self.save or self.cur_where is None:
            return
        kind, a, b = self.cur_where
        r = QMessageBox.warning(self, "Delete Pokémon", "Delete this Pokémon from the save?",
                                QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
        if r != QMessageBox.Yes:
            return
        if kind == "party":
            self.save.remove_party_member(a)
        else:
            self.save.delete_box_pokemon(a, b)
        if self.pkhex:
            self.cur_where = None
            self.editor.where = None
            self.refresh_lists()
        else:
            self.refresh_lists()
            self.editor.setEnabled(False)
            self.on_mon_selected()
        self.status.setText("Pokémon deleted (not yet written to file).")

    # -- PKHeX-style interface: grids, selection, drag & drop ---------------------------------
    def load_template(self):
        """The editor starts with a blank Pokémon (not in any slot): edit it, then drag its sprite
        into a slot or use 'Apply to selected slot'."""
        try:
            self.editor.load(g3.make_new_mon(self.save, self.rom, 1, 5), None)
        except Exception as e:  # noqa: BLE001
            self.status.setText(f"Could not create the blank editor Pokémon: {e}")

    def fill_box_nav(self):
        if self.box_combo is None:
            return
        self.box_combo.blockSignals(True)
        self.box_combo.clear()
        for b in range(self.save.BOXES if self.save else 0):
            self.box_combo.addItem(f"Box {b + 1}", b)
        self.box_combo.setCurrentIndex(min(self.cur_box, max(self.box_combo.count() - 1, 0)))
        self.box_combo.blockSignals(False)

    def set_box(self, i):
        n = self.save.BOXES if self.save else 0
        if not n:
            return
        self.cur_box = i % n
        self.box_combo.blockSignals(True)
        self.box_combo.setCurrentIndex(self.cur_box)
        self.box_combo.blockSignals(False)
        self.refresh_grids(reparse=False)

    def step_box(self, d):
        self.set_box(self.cur_box + d)

    def on_box_combo(self, *_):
        i = self.box_combo.currentIndex()
        if i >= 0 and i != self.cur_box:
            self.set_box(i)

    def refresh_grids(self, reparse=True):
        if self.box_grid is None:
            return
        if not self.save:
            self.box_grid.set_items([])
            self.party_grid.set_items([])
            return
        if reparse or self._box_cache is None:
            self._box_cache = self.save.box_pokemon()
        box_items = [self._box_cache.get((self.cur_box, i)) for i in range(self.save.BOX_SLOTS)]
        party = self.save.party()
        party_items = [party[i] if i < len(party) else None for i in range(6)]
        w = self.cur_where
        sel_box = w[2] if w and w[0] == "box" and w[1] == self.cur_box else -1
        sel_party = w[1] if w and w[0] == "party" else -1
        self.box_grid.set_items(box_items, sel_box)
        self.party_grid.set_items(party_items, sel_party)

    def where_of(self, kind, i):
        return ("box", self.cur_box, i) if kind == "box" else ("party", i, 0)

    def mon_at(self, where):
        kind, a, b = where
        if kind == "party":
            p = self.save.party()
            return p[a] if a < len(p) else None
        return self.save.box_pokemon().get((a, b))

    def select_slot(self, kind, i):
        if not self.save:
            return
        grid = self.box_grid if kind == "box" else self.party_grid
        m = grid.items[i] if i < len(grid.items) else None
        self.cur_where = self.where_of(kind, i)
        if m is not None:
            self.editor.load(m, self.cur_where)
        else:
            self.editor.where = self.cur_where      # empty slot: keep the editor content as the new Pokémon
        self.refresh_grids(reparse=False)
        label = f"Party {i + 1}" if kind == "party" else f"Box {self.cur_box + 1} / slot {i + 1}"
        self.status.setText(f"{label}: " + (self.species_name(m.species) if m else
                                            "empty - 'Apply to selected slot' places the editor Pokémon here"))

    def store_editor(self, where):
        """Writes the editor contents into a slot (overwrites an existing Pokémon, otherwise creates one)."""
        ed = self.editor
        kind, a, b = where
        if kind == "party":
            a = min(a, len(self.save.party()))      # party stays gap-free: empty slots append
            where = ("party", a, 0)
        cur = self.mon_at(where)
        if cur is not None and ed.where == where and ed.mon is not None:
            m = ed.mon
        else:
            m = g3.make_new_mon(self.save, self.rom, ed.species.get_id() or 1, ed.level.value())
        ed.write_into(m)
        if kind == "party":
            if a < len(self.save.party()):
                self.save.set_party_member(a, m)
            else:
                self.save.add_party_member(m)
        else:
            self.save.set_box_pokemon(a, b, m)
        return where

    def apply_pkhex(self):
        if not self.save or self.cur_where is None:
            self.status.setText("Select a slot first (or drag the sprite into one).")
            return
        try:
            where = self.store_editor(self.cur_where)
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Error", str(e))
            return
        self.cur_where = where
        self.refresh_lists()
        self.select_slot(where[0], where[1] if where[0] == "party" else where[2])
        self.status.setText("Pokémon applied (not yet written to file).")

    def handle_drop(self, kind, i, payload):
        if not self.save:
            return
        try:
            if payload == "editor":
                where = self.store_editor(self.where_of(kind, i))
                msg = "Pokémon placed (not yet written to file)."
            elif payload.startswith("slot:"):
                _, skind, sidx = payload.split(":")
                where = self.move_slot(skind, int(sidx), kind, i)
                msg = "Pokémon moved (not yet written to file)." if where else ""
            else:
                return
        except ValueError as e:
            self.status.setText(str(e))
            return
        except Exception as e:  # noqa: BLE001
            QMessageBox.critical(self, "Error", str(e))
            return
        if where:
            self.cur_where = where
        self.refresh_lists()
        if msg:
            self.status.setText(msg)

    def move_slot(self, skind, si, tkind, ti):
        """Drag a Pokémon from one slot to another: box<->box moves or swaps, party->box moves."""
        src, dst = self.where_of(skind, si), self.where_of(tkind, ti)
        if src == dst:
            return None
        sm, dm = self.mon_at(src), self.mon_at(dst)
        if sm is None:
            return None
        if skind == "box" and tkind == "box":
            self.save.set_box_pokemon(dst[1], dst[2], sm)
            if dm is None:
                self.save.delete_box_pokemon(src[1], src[2])
            else:
                self.save.set_box_pokemon(src[1], src[2], dm)
        elif skind == "party" and tkind == "box":
            if dm is not None:
                raise ValueError("That box slot is occupied - move the Pokémon to an empty slot.")
            if len(self.save.party()) <= 1:
                raise ValueError("Keep at least one Pokémon in the party.")
            self.save.set_box_pokemon(dst[1], dst[2], sm)
            self.save.remove_party_member(src[1])
        elif tkind == "party":
            raise ValueError("To put a Pokémon into the party, drag the editor sprite into a party slot.")
        else:
            raise ValueError("Cannot move there.")
        return dst

    def delete_selected(self):
        if self.save and self.cur_where is not None and self.mon_at(self.cur_where) is not None:
            self.delete_mon()

    # -- bag -----------------------------------------------------------------------
    def pocket_key(self):
        k = self.pocket_box.currentData()
        return k if k else self.pocket_box.currentText()

    def fill_pockets(self):
        """Pocket list depends on the save type (Imperium has Mega Stones, Heart & Soul Medicine…)."""
        keys = list(getattr(self.save, "POCKETS", g3.SaveFile.POCKETS)) if self.save else g3.SaveFile.POCKETS
        labels = dict(POCKET_LABELS)
        labels.update(getattr(self.save, "POCKET_LABELS", {}) or {})
        self.pocket_box.blockSignals(True)
        self.pocket_box.clear()
        for k in keys:
            self.pocket_box.addItem(labels.get(k, k), k)
        self.pocket_box.blockSignals(False)

    def allowed_items(self, pocket):
        """Item ids that belong into this pocket, or None when nothing is known about categories."""
        if self.save is not None and hasattr(self.save, "item_filter"):
            f = self.save.item_filter(pocket)
            if f is not None:
                return [i for i in range(self.item_count()) if f(i)]
        if self.rom is not None:
            ids = self.rom.items_for_pocket(pocket)
            if ids:
                return ids
        return None

    def add_bag_row(self, iid, qty):
        r = self.bag_table.rowCount()
        self.bag_table.insertRow(r)
        pocket = self.pocket_key()
        combo = NameCombo(self.item_name, self.item_count(), ids=self.allowed_items(pocket))
        combo.set_id(iid)
        self.bag_table.setCellWidget(r, 0, combo)
        sp = QSpinBox()
        sp.setRange(0, max(self.save.pocket_qty_max(pocket), qty) if self.save else 999)
        sp.setValue(qty)
        self.bag_table.setCellWidget(r, 1, sp)
        rm = QPushButton("✕")
        rm.clicked.connect(lambda _=False, w=combo: self.remove_bag_row(w))
        self.bag_table.setCellWidget(r, 2, rm)
        self.update_bag_info()

    def remove_bag_row(self, combo_widget):
        for r in range(self.bag_table.rowCount()):
            if self.bag_table.cellWidget(r, 0) is combo_widget:
                self.bag_table.removeRow(r)
                break
        self.update_bag_info()

    def update_bag_info(self):
        if not self.save:
            self.bag_info.setText("")
            return
        cap = self.save.pocket_capacity(self.pocket_key())
        n = self.bag_table.rowCount()
        over = "   ⚠ more rows than slots - extra rows will not be saved" if n > cap else ""
        self.bag_info.setText(f"{n} / {cap} slots{over}")

    def load_bag(self, *_):
        self.bag_table.setRowCount(0)
        if not self.save:
            self.update_bag_info()
            return
        for iid, qty in self.save.bag(self.pocket_key()):
            self.add_bag_row(iid, qty)
        self.update_bag_info()

    def apply_bag(self):
        if not self.save:
            return
        pocket = self.pocket_key()
        cap = self.save.pocket_capacity(pocket)
        allowed = self.allowed_items(pocket)
        allowed = set(allowed) if allowed is not None else None
        already = {i for i, _ in self.save.bag(pocket)}
        items, skipped = [], 0
        for r in range(self.bag_table.rowCount()):
            iid = self.bag_table.cellWidget(r, 0).get_id()
            qty = self.bag_table.cellWidget(r, 1).value()
            if not iid:
                continue
            if allowed is not None and iid not in allowed and iid not in already:
                skipped += 1          # a typed id that does not belong into this pocket
                continue
            items.append([iid, qty])
        self.save.set_bag(pocket, items[:cap])
        self.status.setText("Pocket applied (not yet written to file)."
                            + (f"  {len(items) - cap} row(s) dropped (pocket full)." if len(items) > cap else "")
                            + (f"  {skipped} item(s) skipped: they do not belong into this pocket." if skipped else ""))

    def apply_trainer(self):
        if not self.save:
            return
        self.save.trainer_name = self.t_name.text()
        self.save.money = self.t_money.value()
        self.status.setText("Trainer applied (not yet written to file).")


if __name__ == "__main__":
    app = QApplication(sys.argv)
    w = Main()
    w.show()
    # allow:  python romhack_save_editor.py game.gba game.sav
    for arg in sys.argv[1:]:
        if arg.lower().endswith((".gba", ".bin")):
            w.open_rom(arg)
    for arg in sys.argv[1:]:
        if arg.lower().endswith((".sav", ".srm")):
            w.open_save(arg)
    sys.exit(app.exec())
