import struct, random
import gen3lib as g3

random.seed(1)

# ---- synthetic ROM with custom names -----------------------------------------
rom = bytearray(random.randbytes(0x200000))
rom[0xA0:0xAC] = b"TESTHACK\x00\x00\x00\x00"
rom[0xAC:0xB0] = b"BPEE"
# make random area non-text-looking: fine (random bytes rarely form long valid runs)

species = ["??????????", "BULBASAUR", "CUSTOMON", "FOOMIX", "ZETAWING"] + [f"MON{n}" for n in range(5, 420)]
off_sp = 0x100000
for i, n in enumerate(species):
    rom[off_sp + i * 11: off_sp + i * 11 + 11] = g3.encode_text(n, 11)
moves = ["-"] + [f"MOVE{n}" for n in range(1, 400)]
off_mv = 0x140000
for i, n in enumerate(moves):
    rom[off_mv + i * 13: off_mv + i * 13 + 13] = g3.encode_text(n, 13)
items = ["????????"] + ["MASTER BALL", "MEGA STONE X", "CUSTOM CANDY"] + [f"ITEM{n}" for n in range(4, 450)]
off_it = 0x160000
for i, n in enumerate(items):
    rom[off_it + i * 44: off_it + i * 44 + 14] = g3.encode_text(n, 14)
    rom[off_it + i * 44 + 14: off_it + i * 44 + 44] = b"\x00" * 30
    struct.pack_into("<H", rom, off_it + i * 44 + 14, i)          # itemId == index
    struct.pack_into("<I", rom, off_it + i * 44 + 20, 0x08123456)  # description pointer

info = g3.RomInfo(bytes(rom))
print(info.notes)
assert info.species(2) == "CUSTOMON", info.species(2)
assert info.move(5) == "MOVE5"
assert info.item(2) == "MEGA STONE X", info.item(2)

# ---- synthetic Emerald save ---------------------------------------------------
sav = bytearray(b"\xff" * (0x1000 * 14 * 2 + 0x2000))
key = 0xDEADBEEF
for slot, cnt in ((0, 5), (1, 4)):
    base = slot * 0xE000
    for sid in range(14):
        o = base + sid * 0x1000
        sav[o:o + 0xFF4] = b"\x00" * 0xFF4
        struct.pack_into("<HHII", sav, o + 0xFF4, sid, 0, g3.SIGNATURE, cnt)
    s0 = base
    sav[s0:s0 + 8] = g3.encode_text("ASH", 8)
    struct.pack_into("<I", sav, s0 + 0xAC, key)
    s1 = base + 0x1000
    struct.pack_into("<I", sav, s1 + 0x234, 0)  # party count set below for slot 0

# put a custom pokemon into party of slot 0 (active)
def make_mon(species_id, pid, otid, nick, party=True):
    raw = bytearray(100 if party else 80)
    struct.pack_into("<II", raw, 0, pid, otid)
    raw[8:18] = g3.encode_text(nick, 10)
    raw[20:27] = g3.encode_text("ASH", 7)
    p = g3.Pokemon(bytes(raw))
    p.species = species_id
    p.held_item = 2
    p.exp = 1000
    p.set_move(0, 5)
    if party:
        raw2 = bytearray(p.to_bytes())
        raw2[84] = 42
        return bytes(raw2)
    return p.to_bytes()

s1 = 0x1000
struct.pack_into("<I", sav, s1 + 0x234, 1)
sav[s1 + 0x238: s1 + 0x238 + 100] = make_mon(2, 0x12345678, 0x0001E240, "BOBO")
struct.pack_into("<I", sav, s1 + 0x490, 5000 ^ key)
# bag item with encrypted qty
struct.pack_into("<HH", sav, s1 + 0x560, 3, 7 ^ (key & 0xFFFF))

save = g3.SaveFile(bytes(sav))
assert save.game == g3.EMERALD
assert save.slot_offset == 0
assert save.trainer_name == "ASH"
assert save.money == 5000
party = save.party()
assert len(party) == 1
m = party[0]
print(info.species(m.species), m.nickname, m.level, [info.move(x) for x in m.moves], info.item(m.held_item))
assert info.species(m.species) == "CUSTOMON" and m.nickname == "BOBO" and m.level == 42
assert save.bag("items") == [[3, 7]]

# edit + roundtrip
m.species = 3
m.set_move(1, 99)
save.set_party_member(0, m)
save.money = 123456
save.set_bag("items", [[3, 99], [2, 5]])
save.set_box_pokemon(2, 4, g3.Pokemon(make_mon(4, 0xABCDEF01, 0x1111, "ZED", party=False)))
out = save.to_bytes()

s2 = g3.SaveFile(out)
p2 = s2.party()[0]
assert info.species(p2.species) == "FOOMIX" and p2.moves[1] == 99 and p2.level == 42
assert s2.money == 123456
assert s2.bag("items") == [[3, 99], [2, 5]]
bx = s2.box_pokemon()
assert (2, 4) in bx and info.species(bx[(2, 4)].species) == "ZETAWING" and bx[(2, 4)].nickname == "ZED"
# checksum validity
for sid, o in s2.sections.items():
    n = g3.SECTION_DATA_SIZE[sid]
    assert struct.unpack_from("<H", out, o + 0xFF6)[0] == g3.checksum(out[o:o + n])
print("ALL OK")
