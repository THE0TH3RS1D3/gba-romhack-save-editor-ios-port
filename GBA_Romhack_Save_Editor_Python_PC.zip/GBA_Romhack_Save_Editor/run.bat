@echo off
REM Start from source without building an exe.
cd /d "%~dp0"
py -m pip install -r requirements.txt
py romhack_save_editor.py
