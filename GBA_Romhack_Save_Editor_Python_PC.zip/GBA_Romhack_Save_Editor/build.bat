@echo off
REM Builds a standalone RomhackSaveEditor.exe from the sources in this folder.
REM Requires Python 3.10+ for Windows (the "py" launcher). Nothing is precompiled -
REM edit gen3lib.py / romhack_save_editor.py and run this again to rebuild.
cd /d "%~dp0"
py -m venv .venv
call .venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt pyinstaller
pyinstaller --noconfirm --onefile --windowed --name RomhackSaveEditor romhack_save_editor.py
echo.
echo Done: dist\RomhackSaveEditor.exe
pause
