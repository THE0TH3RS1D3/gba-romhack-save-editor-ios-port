# Gen 3 Romhack Save Editor

Save editor for Pokémon GBA games (Ruby/Sapphire/Emerald/FireRed/LeafGreen **and ROM hacks**).
The special part: Pokémon, item and move names are **read from the ROM you open**, so custom
Pokémon / items / moves show up with their real names - no per-hack lists.

## Use
1. `run.bat` (from source) or `build.bat` -> `dist\RomhackSaveEditor.exe`
2. **Open ROM** first (a 32 MB ROM scans in a few seconds the first time, then it is cached in
   `~\.gen3_romhack_editor\cache`), then **Open Save**. Drag & drop of `.gba` + `.sav` works too.
3. Edit party / PC Pokémon, bag pockets, trainer name and money, then **Save**
   (a `.bak` of the old file is written next to it).

## Supported games / romhacks
| Game | Save detection | Notes |
|---|---|---|
| FireRed/LeafGreen, Ruby/Sapphire, Emerald and hacks with the vanilla layout | automatic (layout scoring) | e.g. Girls Hunter |
| Pokémon Unbound (2.0.x / 2.1.x) | by signature | verified with real saves |
| Pokémon Radical Red | by the FireRed signature + security-key pattern (0xAC = 1, key at 0xF20 zero or != copy at 0xAF8) | same CFRU layout as Unbound; shiny threshold 8. **Untested with a real save** - use the layout selector if detection is wrong |
| Pokémon Emerald Legacy | by the Pokédex seen-flag copies + pouch checks | Emerald layout with a 120-slot item pocket; verified with a fixture save |
| Emerald Imperium (1.x) | 28 sectors + checksum lengths | pokeemerald-expansion record format (11-bit species, hidden nature, 12-char nicknames); verified with a fixture save |
| Pokémon Heart & Soul (2.0) | magic number 0xE8F828BC in SaveBlock1 | verified with a fixture save |

The Imperium / Heart & Soul / Legacy / Radical Red layouts were taken from the open-source
[PKHeX.Everywhere](https://github.com/arleypadua/PKHeX.Everywhere) project (GPL-3.0-or-later), so this
program is distributed under the same license. Names (species, moves, items, abilities) are read from the
ROM: the strict scan handles vanilla-style and CFRU/Unbound ROMs; for ROMs that keep names inside bigger
structs (pokeemerald-expansion) there is a fallback that anchors on well-known names (Bulbasaur/Ivysaur,
Pound/Karate Chop, Master Ball/Ultra Ball). That fallback is only tested on synthetic ROMs, because no
Imperium / Heart & Soul ROM was available - if names stay numbers, the ROM stores them as pointers.

## Slots, new Pokémon, bag categories
* The Pokémon tab lists the party and every box slot, **including empty ones** (filter by box, hide empties).
  Select an empty slot -> **Create new Pokémon here** (a level 5 placeholder: trainer as OT, random
  PID/IVs, Tackle, correct stats), then set species, level, moves etc. in the editor and press Apply.
* **Level and Exp are linked** via the species' growth rate from the ROM (changing the level sets the minimum Exp
  of that level, changing Exp updates the level, a species change keeps the level). The level also works for PC
  Pokémon: Gen 3 stores only their Exp, the level is derived from it. **Delete** clears a slot (party members shift up).
* The bag item selector only offers items that belong into the selected pocket (category read from the ROM's
  item structs; Heart & Soul uses its own pocket table). A typed id that does not belong there is skipped
  with a message, so a Master Ball can no longer end up in the berry pocket.
* Per-pocket stack limits (e.g. key items 1, Legacy items 99); existing larger values are kept.
* Layout selector: Auto, Unbound, Radical Red, Emerald Legacy, Imperium, Heart & Soul, RS, FRLG, Emerald.

## Sprite preview (optional)
**Settings… → Sprite preview** (off by default, remembered between runs) shows a small front sprite of the selected
Pokémon next to the editor's info line (shiny palette when *Shiny* is ticked); the big list never loads
sprites. The sprites are read from the ROM: the first time it is switched on the ROM is scanned for the
64x64 4bpp LZ77 picture tables (`{pointer, size, tag}` entries, tag = species index) and the normal / shiny
palette tables (0.5-2 s, then cached). Which of the two picture tables is the front one is decided by a
heuristic (back pictures are drawn larger). Checked with FireRed, Girls Hunter 1/3 and Unbound; other hacks
that keep vanilla-style tables should work, hacks with another sprite format show "no sprite".

## Settings and the PKHeX-style interface (optional)
The **Settings…** button in the top bar holds these switches, all off by default (stored in
`~/.gen3_romhack_editor/settings.json`): *Sprite preview*, *Larger sprite in the classic interface* (a big
sprite right of species / nickname / held item, which get a bit shorter; needs the sprite preview) and
*PKHeX-style interface*. The classic
interface is unchanged unless you switch the second one on; switching rebuilds the window and keeps the
loaded ROM / save.

PKHeX-style mode (needs sprites, so they are switched on while it is active):
- **Left:** tabbed editor - Main (PID, species, nickname, Exp/Level, nature, item, ability, friendship,
  shiny), Met (ball), Stats (base / IV / EV / calculated stats, totals, Hidden Power, randomize buttons),
  Attacks (moves + PP), OT/Misc (OT, TID, SID). The preview sprite sits in a frame above the tabs.
- **Right:** Box (6x5 grid on the PKHeX box background, `<<` / `>>` / box list), Party, Bag, SAV
  (trainer block + the ROM / save overview only).
- **Drag the preview sprite** into a box or party slot: a copy of the Pokémon currently in the editor is
  placed there (empty party cells append). The editor starts with a blank Pokémon, so you can build one
  and drop it. **Drag a slot** onto another: moves it to an empty slot or swaps box slots; a party
  Pokémon can be dragged into an empty box slot. Box -> party is done through the editor sprite instead.
- **Click** a slot to load it into the editor, change things, press *Apply to selected slot* (on an empty
  slot it creates the Pokémon). **Hover** a Pokémon for one second for a summary (IVs, ability, level,
  nature, moves). **Del** key or right-click deletes the selected Pokémon (with confirmation).

## IVs, EVs, nature, ability, shiny
The Pokémon panel edits IVs (0-31), EVs (0-255, total shown vs. 510), nature, ability slot
(1 / 2 / hidden for Unbound), shiny, happiness and (Unbound) ball. Nature, ability parity and shiny
live in the PID, so the editor searches the nearest PID with the wanted combination that keeps the
gender. Base stats, gender ratio, growth rate and ability names are read from the ROM
(base-stat table: 28-byte entries; ability names: 13-byte vanilla / 17-byte Unbound table), so this
works for hacks with new species too. Shiny threshold: 8 (vanilla) / 16 (Unbound).
`python test_ivs.py` is not shipped; the logic was verified by recomputing the stored party stats
of a real Unbound save (exact match for all 6 Pokémon).

## How the ROM detection works (`gen3lib.RomInfo`)
Nothing is hard-coded to a hack. The ROM is searched by structure:
* **Species / move names**: a long run of fixed-size, 0xFF-terminated Gen 3 strings (stride 11 /
  13). The start is aligned on the placeholder entry 0 (`?????` / `-`).
* **Items**: a table of 44-byte structs; each entry has its `itemId` at +14 and a ROM pointer at
  +20. Names are looked up by that `itemId` (this matters for expanded tables like Unbound's).

## How the save handling works (`gen3lib.SaveFile`)
* Two slots of 14 rotating 4 KB sections; the newest valid slot is used. The section signature
  is learned from the file (vanilla `0x08012025`, Unbound `0x01121998`).
* The layout (Ruby/Sapphire, FireRed/LeafGreen, Emerald) is auto-detected by trying all three and
  scoring them (valid Pokémon checksums, sane money). Override it with the *Save layout* box.
* Checksum section sizes are detected per section from the stored checksums, so expanded saves are
  not corrupted. For non-standard saves only the sections you change are rewritten.

## Pokémon Unbound
Unbound is a heavily modified FireRed (CFRU engine) with its own save layout. Support is based on
the layout documented by the **PUSE** editor (Zannael/PUSE, MIT licence) and verified against real
saves from versions 2.0.3.2 / 2.1.1.1 (saves work with both ROM versions).
* **Recognition:** ROMs by SHA-1 (2.0.3.2 and 2.1.1.1) or by in-ROM text; saves by their section
  signature (`0x01121998` / `0x01121999`). The info tab shows what was recognised; a warning appears
  if ROM and save do not belong together.
* **Name tables** are found structurally (species 1294 / items 729 / moves 930 in 2.1.1.1). Table
  starts are confirmed by a ROM pointer to them. The base PP of every move is read from the ROM's
  battle-move table, so replacing a move in the party also sets a sensible PP.
* **Checksums:** sections 0 / 4 / 13 only cover 3876 / 3480 / 1104 bytes, all others 4080. Section 4
  is treated as opaque and never rewritten. Only sections you change are rewritten.
* **Party:** 100-byte records, *not encrypted* (sub-structures B, A, D, C in fixed order).
* **PC:** 24 boxes x 30 slots of compact 58-byte records (10-bit move ids), stored as one stream
  across several sections plus the auxiliary sectors 30 / 31.
* **Bag:** unencrypted `{item, quantity}` slots: main pocket (section 13 + 2776), key items / balls /
  TMs / berries (aux sector 30). Pocket capacity = current items + the free slots behind them.
* **Money:** u32 (max 999,999,999) plus the 3-byte BCD copy. The 16-byte RTC trailer of the save
  file is preserved.
* Not supported for Unbound: EV/IV/ability/nature editing, Pokédex, presets, battle points and the
  level of PC Pokémon (the game derives it from experience).

## Tested with
Pokémon FireRed (a 100 % save), Pokémon Girls Hunter 1 and 3, Pokémon Unbound 2.0.3.2 / 2.1.1.1
(a save with a full team, 69 PC Pokémon and a filled bag): names, party, PC, bag, key items, money
and trainer are read, edited, written and reloaded with valid checksums.
`python test_gen3.py` runs a self-contained synthetic round-trip test.

## Known limits
* No Pokédex editing yet. Party stats are recalculated on Apply (checkbox) from the ROM's base-stat
  table; if a hack changes the stat formula or the table can't be found, they refresh on next level-up.
* Hacks that move the save structures (big engine rewrites) may need an entry in
  `SaveFile._layout()` in `gen3lib.py`.
* Only the Western character set is decoded; unknown glyphs show as `?`.
* The window itself could not be rendered in the development sandbox (Qt was not installable
  there); the program logic was tested headlessly against the real ROMs/saves. If the UI misbehaves,
  please report what you see.
