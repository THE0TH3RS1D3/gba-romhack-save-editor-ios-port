"""Box background (156x116 PNG) used by the PKHeX-style interface, embedded so that no extra files
have to be shipped next to the exe."""
BOX_BG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAJwAAAB0BAMAAACCgUaRAAAAJFBMVEX4+PhPfxdnly93Xyd/r0eXyF+fh0+nr4ev4HfI0KfI+I/g"
    "+KdNhK7DAAAAAXRSTlMAQObYZgAAANVJREFUeNrt1LEJwkAYhuEDwV7cwBUCDiBkg/u5pIsI11hnASEjZAMLcQAbl5MjYMD2/0IK"
    "36/5ueaFEHjCNgvXhazcJeTrW7ZXFfJTl7uXnG6nkjPV4qHkBnEupenpunMuxunpuAvmzL3lc33vvXNuHK2uvXfODYPVtev+5sxc"
    "d6U/u34uJbO29d5vLkazpvFecQ7v8A7v8A7v8A7v8A7v8A7v8A7v8A7v8A7v8A7v8A7v8A7v8A7v8O4/vdN/7OMgW8nddrKV3FmX"
    "21chV8Idw0aZ6z5LxDhaPRQNMQAAAABJRU5ErkJggg=="
)
